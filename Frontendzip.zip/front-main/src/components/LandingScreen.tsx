import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowUp, Mic, Sparkles, Zap, ArrowRight,
  CheckCircle, Briefcase, MapPin, BookOpen, TrendingUp,
  Star, Users, ChevronRight,
} from 'lucide-react';

interface LandingScreenProps {
  onSend: (text: string) => void;
}

const PROMPTS = [
  { icon: Briefcase, label: 'Find jobs for my skills',     prompt: 'I know HTML, CSS and JavaScript. What jobs can I get without a degree?' },
  { icon: MapPin,    label: 'Jobs near me',                prompt: 'Show me entry-level tech jobs near me I can apply to right now.' },
  { icon: BookOpen,  label: 'Build my roadmap',            prompt: 'Build me a 3-month roadmap to become a frontend developer.' },
  { icon: TrendingUp,label: 'Analyse my skill gaps',       prompt: 'What skills am I missing to get hired as a data analyst?' },
];

const PLACEHOLDERS = [
  'I know Python but have no degree. Help me get a job…',
  'What jobs can I get with HTML, CSS and JavaScript?',
  'Build me a 3-month roadmap for UI/UX design…',
  'Analyse my skills and tell me what I am missing…',
];

const REVIEWS = [
  { name: 'Riya S.',  role: 'Frontend Developer',          text: 'Got hired in 6 weeks. No degree, just proof of work.',      init: 'RS' },
  { name: 'Aman K.',  role: 'Full-stack Dev at a startup', text: 'Findy showed me exactly what was missing and I fixed it.',   init: 'AK' },
  { name: 'Priya M.', role: 'Junior Data Analyst',         text: 'The skill-gap breakdown was more useful than any bootcamp.', init: 'PM' },
];

export const LandingScreen: React.FC<LandingScreenProps> = ({ onSend }) => {
  const [input, setInput] = useState('');
  const [ph, setPh] = useState(0);
  const [rev, setRev] = useState(0);
  const [isRec, setIsRec] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const t = setInterval(() => setPh(p => (p + 1) % PLACEHOLDERS.length), 3200);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    const t = setInterval(() => setRev(p => (p + 1) % REVIEWS.length), 3500);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 150)}px`;
    }
  }, [input]);

  const send = (text: string) => {
    const t = text.trim();
    if (t) onSend(t);
  };

  return (
    <div className="relative flex min-h-screen w-full flex-col items-center overflow-x-hidden bg-black">

      {/* Background */}
      <div className="pointer-events-none absolute inset-0"
        style={{ backgroundImage: 'radial-gradient(rgba(255,255,255,0.05) 1px, transparent 1px)', backgroundSize: '30px 30px' }} />
      <div className="pointer-events-none absolute -top-48 left-1/2 h-[520px] w-[700px] -translate-x-1/2 rounded-full bg-[#f5c842] opacity-[0.06] blur-[140px]" />

      {/* Nav */}
      <nav className="relative z-20 flex w-full items-center justify-between border-b border-white/[0.06] bg-black/80 px-6 py-4 backdrop-blur-xl sm:px-12">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg border border-[#f5c842]/30 bg-[#f5c842]/10">
            <Sparkles size={14} className="text-[#f5c842]" />
          </div>
          <span className="text-[15px] font-bold text-white">Findy</span>
          <span className="rounded-full border border-[#f5c842]/25 bg-[#f5c842]/10 px-2 py-0.5 text-[10px] font-bold text-[#f5c842]">AI</span>
        </div>
        <div className="flex items-center gap-3">
          <div className="hidden items-center gap-1.5 rounded-full border border-white/[0.07] px-3 py-1 sm:flex">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#f5c842]" />
            <span className="text-xs text-zinc-500">Live & free</span>
          </div>
          <button onClick={() => send('Help me find a job')}
            className="flex items-center gap-1.5 rounded-xl bg-[#f5c842] px-4 py-2 text-sm font-bold text-black transition-all hover:bg-[#f8d45f] active:scale-95">
            Get started <ChevronRight size={14} />
          </button>
        </div>
      </nav>

      {/* Hero */}
      <div className="relative z-10 flex w-full max-w-2xl flex-col items-center px-5 pt-20 pb-10 text-center sm:pt-28">

        {/* Eyebrow badge */}
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}
          className="mb-6 inline-flex items-center gap-2 rounded-full border border-[#f5c842]/20 bg-[#f5c842]/[0.07] px-4 py-1.5">
          <Zap size={11} className="text-[#f5c842]" />
          <span className="text-xs font-medium text-[#f5c842]/80">AI-powered career intelligence for skill-first people</span>
        </motion.div>

        {/* Headline */}
        <motion.h1 initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className="text-[52px] font-extrabold leading-[1.08] tracking-[-0.04em] text-white sm:text-[64px]">
          Turn your skills into<br />
          <span className="relative text-[#f5c842]">
            a real career.
            <motion.div initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ delay: 0.7, duration: 0.5 }}
              className="absolute -bottom-1 left-0 right-0 h-[2px] origin-left rounded-full bg-[#f5c842]/40" />
          </span>
        </motion.h1>

        <motion.p initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.18 }}
          className="mt-5 max-w-[430px] text-[15px] leading-7 text-zinc-500">
          Describe what you know. Findy maps the jobs you can get, the skills you're missing, and a step-by-step roadmap to get hired — no degree needed.
        </motion.p>

        {/* ── INPUT (fully functional) ── */}
        <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.26 }}
          className="mt-9 w-full">
          <div className={`flex w-full flex-col rounded-2xl border bg-[#0e0e0e] shadow-2xl shadow-black transition-all duration-200 ${
            input ? 'border-[#f5c842]/40' : 'border-white/[0.08] focus-within:border-[#f5c842]/30'
          }`}>
            <textarea
              ref={textareaRef}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(input); } }}
              placeholder={PLACEHOLDERS[ph]}
              rows={1}
              className="scrollbar-hide max-h-[150px] w-full resize-none bg-transparent px-5 pt-4 pb-2 text-[15px] leading-7 text-white placeholder-zinc-700 outline-none"
            />
            <div className="flex items-center justify-between px-4 pb-3 pt-1">
              <div className="flex items-center gap-2">
                <button onClick={() => setIsRec(r => !r)}
                  className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium transition-all ${
                    isRec ? 'animate-pulse border border-red-500/30 bg-red-500/10 text-red-400' : 'text-zinc-600 hover:bg-white/[0.04] hover:text-zinc-300'
                  }`}>
                  <Mic size={12} />
                  {isRec ? 'Stop' : 'Voice'}
                </button>
                <span className="hidden text-[11px] text-zinc-800 sm:block">Enter to send · Shift+Enter for newline</span>
              </div>
              <button onClick={() => send(input)} disabled={!input.trim()}
                className={`flex h-9 w-9 items-center justify-center rounded-xl transition-all ${
                  input.trim() ? 'bg-[#f5c842] text-black shadow shadow-[#f5c842]/20 hover:scale-105 hover:bg-[#f8d45f] active:scale-95' : 'cursor-not-allowed bg-white/[0.04] text-zinc-700'
                }`}>
                <ArrowUp size={16} strokeWidth={2.5} />
              </button>
            </div>
          </div>
        </motion.div>

        {/* Prompt chips */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.34 }}
          className="mt-3 flex w-full flex-wrap justify-center gap-2">
          {PROMPTS.map(p => (
            <button key={p.label} onClick={() => send(p.prompt)}
              className="flex items-center gap-1.5 rounded-xl border border-white/[0.07] bg-white/[0.02] px-3 py-1.5 text-[12.5px] text-zinc-500 transition-all hover:border-[#f5c842]/30 hover:bg-[#f5c842]/[0.05] hover:text-[#f5c842]">
              <p.icon size={11} />
              {p.label}
            </button>
          ))}
        </motion.div>
      </div>

      {/* ── Chat preview mockup ── */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.42 }}
        className="relative z-10 w-full max-w-2xl px-5">
        <div className="overflow-hidden rounded-2xl border border-white/[0.07] bg-[#0e0e0e] shadow-2xl shadow-black">
          {/* Window chrome */}
          <div className="flex items-center gap-1.5 border-b border-white/[0.06] px-4 py-3">
            <span className="h-2.5 w-2.5 rounded-full bg-red-500/60" />
            <span className="h-2.5 w-2.5 rounded-full bg-yellow-500/60" />
            <span className="h-2.5 w-2.5 rounded-full bg-green-500/60" />
            <span className="ml-3 text-[11px] text-zinc-700">Findy AI — Career chat</span>
          </div>

          <div className="space-y-4 p-5">
            {/* User message */}
            <div className="flex justify-end">
              <div className="max-w-[78%] rounded-2xl rounded-tr-sm border border-white/[0.07] bg-[#161616] px-4 py-2.5 text-[13px] leading-6 text-zinc-300">
                I know HTML, CSS, and JavaScript but I have no degree. What jobs can I get right now?
              </div>
            </div>

            {/* AI response */}
            <div className="flex gap-3">
              <div className="mt-0.5 flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-lg border border-[#f5c842]/25 bg-[#f5c842]/10">
                <Sparkles size={12} className="text-[#f5c842]" />
              </div>
              <div className="flex-1 space-y-3">
                <p className="text-[11px] font-semibold text-[#f5c842]/60">Findy AI</p>
                <p className="text-[13px] leading-6 text-zinc-400">
                  Your degree is not the blocker — your <span className="text-white font-medium">proof of work</span> is. With HTML, CSS and JS you can apply for these roles today:
                </p>
                {/* Role cards */}
                <div className="grid gap-2 sm:grid-cols-3">
                  {[
                    { title: 'Junior Frontend Dev', tag: 'Walk-in', tagCol: 'text-emerald-400 bg-emerald-400/10 border-emerald-400/20', salary: '$60k–$80k' },
                    { title: 'Freelance Web Dev',   tag: 'Remote',   tagCol: 'text-blue-400 bg-blue-400/10 border-blue-400/20',     salary: '$20–35/hr' },
                    { title: 'React Developer',     tag: 'Email HR', tagCol: 'text-[#f5c842] bg-[#f5c842]/10 border-[#f5c842]/20', salary: '$75k–$100k' },
                  ].map(r => (
                    <div key={r.title} className="rounded-xl border border-white/[0.06] bg-[#161616] p-3">
                      <p className="text-[12px] font-semibold text-white">{r.title}</p>
                      <p className="mt-1 text-[11px] text-zinc-600">{r.salary}</p>
                      <span className={`mt-2 inline-block rounded-md border px-2 py-0.5 text-[10px] font-semibold ${r.tagCol}`}>{r.tag}</span>
                    </div>
                  ))}
                </div>
                {/* Skill progress */}
                <div className="rounded-xl border border-white/[0.06] bg-[#161616] p-3">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-[12px] font-semibold text-white">Job readiness</p>
                    <span className="text-[11px] text-[#f5c842]">62%</span>
                  </div>
                  <div className="h-1.5 overflow-hidden rounded-full bg-white/[0.06]">
                    <motion.div initial={{ width: 0 }} animate={{ width: '62%' }} transition={{ delay: 0.8, duration: 0.9 }}
                      className="h-full rounded-full bg-[#f5c842]" />
                  </div>
                  <p className="mt-2 text-[11px] text-zinc-600">Build 2 proof projects to reach 85%+ and get noticed.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* ── Social proof & stats ── */}
      <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}
        className="relative z-10 mt-6 w-full max-w-2xl px-5">
        {/* Stats */}
        <div className="grid grid-cols-3 gap-2.5">
          {[
            { val: '12,000+', lbl: 'users helped' },
            { val: '98%',     lbl: 'no-degree paths' },
            { val: '4.9 / 5', lbl: 'average rating' },
          ].map(s => (
            <div key={s.lbl} className="flex flex-col items-center gap-0.5 rounded-xl border border-white/[0.05] bg-[#0e0e0e] py-3.5">
              <span className="text-[18px] font-bold text-white">{s.val}</span>
              <span className="text-[11px] text-zinc-700">{s.lbl}</span>
            </div>
          ))}
        </div>

        {/* Review */}
        <div className="mt-3 overflow-hidden rounded-xl border border-white/[0.05] bg-[#0e0e0e] px-5 py-4">
          <div className="mb-3 flex items-center gap-2">
            <div className="flex -space-x-1.5">
              {REVIEWS.map(r => (
                <div key={r.init} className="flex h-6 w-6 items-center justify-center rounded-full border border-black bg-[#f5c842] text-[9px] font-bold text-black">
                  {r.init}
                </div>
              ))}
            </div>
            <div className="flex gap-0.5">
              {[...Array(5)].map((_, i) => <Star key={i} size={10} className="fill-[#f5c842] text-[#f5c842]" />)}
            </div>
            <span className="text-[11px] text-zinc-700">Loved by 12,000+ users</span>
          </div>
          <div className="relative h-14">
            {REVIEWS.map((r, i) => (
              <AnimatePresence key={i} mode="wait">
                {rev === i && (
                  <motion.div key={i} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }}
                    transition={{ duration: 0.3 }} className="absolute inset-0">
                    <p className="text-[13px] italic text-zinc-400">"{r.text}"</p>
                    <p className="mt-1 text-[11px] font-semibold text-zinc-600">{r.name} · {r.role}</p>
                  </motion.div>
                )}
              </AnimatePresence>
            ))}
          </div>
          <div className="mt-3 flex gap-1.5">
            {REVIEWS.map((_, i) => (
              <button key={i} onClick={() => setRev(i)}
                className={`h-1 rounded-full transition-all ${i === rev ? 'w-5 bg-[#f5c842]' : 'w-1 bg-white/10'}`} />
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="mt-6 flex flex-col items-center gap-3 pb-16">
          <button onClick={() => send('Help me find a job based on my skills')}
            className="group relative overflow-hidden rounded-2xl bg-[#f5c842] px-8 py-3.5 text-[14px] font-bold text-black shadow-lg shadow-[#f5c842]/20 transition-all hover:scale-[1.03] hover:shadow-[#f5c842]/30 active:scale-[0.98]">
            <div className="absolute inset-0 bg-white/10 opacity-0 transition-opacity group-hover:opacity-100" />
            <span className="relative flex items-center gap-2">
              <Sparkles size={14} />
              Start for free — no signup needed
              <ArrowRight size={14} className="transition-transform group-hover:translate-x-0.5" />
            </span>
          </button>
          <div className="flex items-center gap-4 text-[11px] text-zinc-700">
            <span className="flex items-center gap-1"><CheckCircle size={10} className="text-[#f5c842]/50" /> No account</span>
            <span className="flex items-center gap-1"><CheckCircle size={10} className="text-[#f5c842]/50" /> Free forever</span>
            <span className="flex items-center gap-1"><Users size={10} className="text-[#f5c842]/50" /> 12K+ users</span>
          </div>
        </div>

        <p className="pb-6 text-center text-[11px] text-zinc-800">
          Findy AI can make mistakes. Always verify important career information independently.
        </p>
      </motion.div>
    </div>
  );
};
