import React from 'react';
import { motion } from 'framer-motion';
import type { Message } from '../types';
import { Sparkles, User, ExternalLink } from 'lucide-react';
import {
  PlanSystemCard, OpportunitiesList, SkillAnalysisCard,
  RiskMeter, RoadmapTimeline, ResourcesGrid, JobsMapCard,
  BackendOpportunitiesCard, BackendLearningPlanCard
} from './RichCards';

const renderFormattedText = (text: string) => {
  return text.split('\n').map((line, lineIndex) => {
    // If line starts with 🔹, make it a nice header
    const isHeader = line.trim().startsWith('🔹');
    
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    const parts = line.split(urlRegex);
    
    const formattedLine = parts.map((part, i) => {
      if (part.match(urlRegex)) {
        return (
          <a key={i} href={part} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 rounded-md bg-blue-50/80 px-2 py-0.5 text-blue-600 font-bold hover:bg-blue-100 hover:shadow-sm transition-all mx-1 text-[12px] align-baseline border border-blue-200/50 shadow-sm">
            View Link <ExternalLink size={10} strokeWidth={2.5} />
          </a>
        );
      }

      // Auto-bold anything before '→' or ':' to make it readable
      if (!isHeader && (part.includes('→') || part.includes(':'))) {
        const splitChar = part.includes('→') ? '→' : ':';
        const segments = part.split(splitChar);
        if (segments.length === 2 && segments[0].length < 50) {
          return (
            <span key={i}>
              <strong className="font-bold text-[#1a1a1a]">{segments[0]}</strong>
              <span className="text-[#9a9a9a] font-medium mx-1">{splitChar}</span>
              {segments[1]}
            </span>
          );
        }
      }
      
      // Basic bold markdown support
      const boldRegex = /(\*\*.*?\*\*)/g;
      const boldParts = part.split(boldRegex);
      return boldParts.map((bp, j) => {
        if (bp.startsWith('**') && bp.endsWith('**')) {
          return <strong key={j} className="font-bold text-[#1a1a1a]">{bp.slice(2, -2)}</strong>;
        }
        return <span key={j}>{bp}</span>;
      });
    });

    return (
      <div key={lineIndex} className={`mb-1.5 ${isHeader ? 'mt-4 mb-2 font-black text-[15px] text-[#1a1a1a] flex items-center gap-1.5' : 'text-[#3a3a3a]'}`}>
        {formattedLine}
      </div>
    );
  });
};

export const ChatMessage: React.FC<{ message: Message }> = ({ message }) => {
  const isUser = message.role === 'user';

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={`flex w-full px-2 py-2 ${isUser ? 'justify-end' : 'justify-start'}`}
    >
      <div className={`flex gap-3 ${isUser ? 'max-w-[80%] flex-row-reverse' : 'w-full'}`}>

        {/* Avatar */}
        <div className="mt-0.5 flex-shrink-0">
          {isUser ? (
            <div className="flex h-7 w-7 items-center justify-center rounded-full bg-[#1a1a1a] text-white">
              <User size={13} />
            </div>
          ) : (
            <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-[#1a1a1a]">
              <Sparkles size={12} className="text-[#f5c842]" />
            </div>
          )}
        </div>

        {/* Content */}
        <div className={`min-w-0 ${isUser ? '' : 'flex-1'}`}>
          <p className={`mb-1.5 text-[11px] font-semibold ${isUser ? 'text-right text-[#9a9a9a]' : 'text-[#9a9a9a]'}`}>
            {isUser ? 'You' : 'Findy AI'}
          </p>

          {isUser ? (
            <div className="rounded-2xl rounded-tr-sm border border-black/[0.07] bg-white px-4 py-2.5 text-[14px] leading-6 text-[#1a1a1a] shadow-sm">
              <p className="whitespace-pre-wrap">{message.content as string}</p>
            </div>
          ) : (
            <div className="space-y-3">
              {typeof message.content === 'object' && (
                <>
                  {/* --- NEW BACKEND STRUCTURE --- */}
                  {message.content.response && (
                    <div className="rounded-2xl rounded-tl-sm border border-black/[0.04] bg-gradient-to-b from-white to-[#fcfcfc] px-5 py-4 text-[14px] leading-relaxed shadow-sm ring-1 ring-black/[0.02]">
                      <div className="whitespace-pre-wrap">{renderFormattedText(message.content.response)}</div>
                    </div>
                  )}
                  {message.content.data?.intent?.intent === 'opportunity' && message.content.data.opportunities && (
                    <BackendOpportunitiesCard opsData={message.content.data.opportunities} />
                  )}
                  {message.content.data?.intent?.intent === 'learning' && message.content.data.learning_plan && (
                    <BackendLearningPlanCard plan={message.content.data.learning_plan} />
                  )}

                  {/* --- LEGACY MOCK STRUCTURE (Fallback) --- */}
                  {message.content.textResponse && !message.content.response && (
                    <div className="rounded-2xl rounded-tl-sm border border-black/[0.04] bg-gradient-to-b from-white to-[#fcfcfc] px-5 py-4 text-[14px] leading-relaxed shadow-sm ring-1 ring-black/[0.02]">
                      <div className="whitespace-pre-wrap">{renderFormattedText(message.content.textResponse)}</div>
                    </div>
                  )}
                  {!message.content.data && message.content.role && (
                    <PlanSystemCard
                      role={message.content.role}
                      risk={message.content.risk}
                      opportunityCount={message.content.opportunities?.length}
                      roadmapCount={message.content.roadmap?.length}
                    />
                  )}
                  {!message.content.data && message.content.opportunities?.length > 0 && <OpportunitiesList ops={message.content.opportunities} />}
                  {!message.content.data && message.content.mapPoints?.length > 0 && <JobsMapCard points={message.content.mapPoints} />}
                  {!message.content.data && message.content.skills && <SkillAnalysisCard skills={message.content.skills} />}
                  {!message.content.data && message.content.risk && <RiskMeter risk={message.content.risk} />}
                  {!message.content.data && message.content.roadmap?.length > 0 && <RoadmapTimeline steps={message.content.roadmap} />}
                  {!message.content.data && message.content.resources?.length > 0 && <ResourcesGrid resources={message.content.resources} />}
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
};
