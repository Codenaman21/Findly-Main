import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Globe, AlertTriangle, TrendingUp, Shield, Activity, Users, Sparkles, ChevronDown, Search, Check } from 'lucide-react';
import { RealWorldMap } from './RealWorldMap';
import { COUNTRIES, GLOBAL_STATS } from './data';
import type { CountryData } from './data';
import { LaborOverview, RiskDistribution, HiringDemand, AutomationRisk, SkillGap, PolicyRecommendations } from './Panels';

export const GovDashboard: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const [selected, setSelected] = useState<CountryData | null>(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [search, setSearch] = useState('');
  const detailRef = useRef<HTMLDivElement>(null);

  const handleSelect = (c: CountryData) => {
    setSelected(c);
    setSearchOpen(false);
    setSearch('');
    setTimeout(() => detailRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 150);
  };

  const filtered = COUNTRIES.filter(c => c.name.toLowerCase().includes(search.toLowerCase()));

  const riskColor = (score: number) => score >= 60 ? '#ef4444' : score >= 40 ? '#f59e0b' : '#10b981';
  const riskLabel = (score: number) => score >= 60 ? 'High' : score >= 40 ? 'Medium' : 'Low';
  const riskBg = (score: number) => score >= 60 ? 'bg-red-50 text-red-700 border-red-200' : score >= 40 ? 'bg-amber-50 text-amber-700 border-amber-200' : 'bg-emerald-50 text-emerald-700 border-emerald-200';

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 font-sans pb-20">
      {/* ── Header ─────────────────────────────────────────── */}
      <header className="sticky top-0 z-50 border-b border-gray-200 bg-white/90 backdrop-blur-md">
        <div className="max-w-7xl mx-auto flex items-center justify-between px-6 py-4">
          <div className="flex items-center gap-4">
            <button onClick={onBack} className="p-2.5 rounded-xl border border-gray-200 bg-white hover:bg-gray-50 transition-colors shadow-sm">
              <ArrowLeft size={18} className="text-gray-600" />
            </button>
            <div className="w-px h-8 bg-gray-200" />
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl flex items-center justify-center bg-blue-600 shadow-md shadow-blue-600/20 text-white">
                <Globe size={18} />
              </div>
              <div>
                <p className="text-[16px] font-black tracking-tight text-gray-900">Global Labor Intelligence</p>
                <p className="text-[10px] font-bold text-gray-500 uppercase tracking-[0.15em]">Decision System · Gov & NGO</p>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <div className="px-4 py-2 rounded-xl bg-emerald-50 border border-emerald-100 text-[12px] font-bold text-emerald-700 flex items-center gap-2 shadow-sm">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" /> Live ILO Data
            </div>

            <div className="relative">
              <button onClick={() => setSearchOpen(!searchOpen)}
                className={`flex items-center gap-3 px-4 py-2.5 rounded-xl border transition-all shadow-sm min-w-[240px] justify-between ${searchOpen ? 'border-blue-500 bg-blue-50/50 ring-4 ring-blue-500/10' : 'border-gray-200 bg-white hover:border-gray-300 hover:bg-gray-50'}`}>
                <div className="flex items-center gap-3">
                  {selected ? (
                    <div className="flex items-center justify-center w-7 h-7 rounded-lg shadow-sm" style={{ backgroundColor: riskColor(selected.riskScore), color: 'white' }}>
                      <Globe size={14} />
                    </div>
                  ) : (
                    <div className="flex items-center justify-center w-7 h-7 rounded-lg bg-gray-100 text-gray-500 shadow-sm border border-gray-200">
                      <Search size={14} />
                    </div>
                  )}
                  <span className={`text-[14px] font-bold ${selected ? 'text-gray-900' : 'text-gray-500'}`}>
                    {selected ? selected.name : 'Search Country...'}
                  </span>
                </div>
                <ChevronDown size={16} className={`transition-transform duration-300 ${searchOpen ? 'rotate-180 text-blue-600' : 'text-gray-400'}`} />
              </button>
              
              <AnimatePresence>
                {searchOpen && (
                  <motion.div initial={{ opacity: 0, y: -10, scale: 0.95 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -10, scale: 0.95 }} transition={{ duration: 0.15, ease: 'easeOut' }}
                    className="absolute right-0 top-[calc(100%+8px)] w-[340px] rounded-2xl border border-gray-200 bg-white shadow-2xl overflow-hidden z-50 ring-1 ring-black/5">
                    
                    {/* Search Input Area */}
                    <div className="p-3 bg-gray-50/80 backdrop-blur-sm border-b border-gray-100">
                      <div className="flex items-center gap-2.5 px-3.5 py-3 rounded-xl bg-white border border-gray-200 shadow-sm focus-within:border-blue-500 focus-within:ring-4 focus-within:ring-blue-500/10 transition-all">
                        <Search size={16} className="text-gray-400" />
                        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Type a country name..."
                          className="flex-1 bg-transparent text-[14px] font-bold text-gray-900 placeholder-gray-400 outline-none" autoFocus />
                      </div>
                    </div>

                    {/* Results List */}
                    <div className="max-h-[340px] overflow-y-auto p-2 scrollbar-hide">
                      {filtered.length > 0 ? filtered.map(c => (
                        <button key={c.id} onClick={() => handleSelect(c)}
                          className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl text-left transition-all ${selected?.id === c.id ? 'bg-blue-50 border border-blue-100 shadow-sm' : 'hover:bg-gray-50 border border-transparent'}`}>
                          
                          <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 shadow-sm" style={{ backgroundColor: `${riskColor(c.riskScore)}15`, border: `1px solid ${riskColor(c.riskScore)}30` }}>
                            <span className="text-[12px] font-black" style={{ color: riskColor(c.riskScore) }}>{c.id}</span>
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <p className="text-[14px] font-bold text-gray-900 truncate">{c.name}</p>
                            <div className="flex items-center gap-2 mt-0.5">
                              <span className="flex items-center gap-1 text-[11px] font-bold text-gray-500">
                                <Activity size={10} /> {c.riskScore}/100
                              </span>
                              <span className="w-1 h-1 rounded-full bg-gray-300" />
                              <span className="text-[11px] font-bold uppercase tracking-wider" style={{ color: riskColor(c.riskScore) }}>
                                {riskLabel(c.riskScore)} Risk
                              </span>
                            </div>
                          </div>

                          {selected?.id === c.id && (
                             <div className="w-5 h-5 rounded-full bg-blue-600 flex items-center justify-center text-white shadow-sm flex-shrink-0">
                               <Check size={12} strokeWidth={3} />
                             </div>
                          )}
                        </button>
                      )) : (
                        <div className="text-center py-10">
                          <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-3 border border-gray-200">
                            <Search size={20} className="text-gray-400" />
                          </div>
                          <p className="text-[14px] font-bold text-gray-900">No countries found</p>
                          <p className="text-[12px] text-gray-500 mt-1">Try a different search term</p>
                        </div>
                      )}
                    </div>
                    
                    {/* Footer */}
                    <div className="p-3 border-t border-gray-100 bg-gray-50 flex justify-between items-center">
                       <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">{filtered.length} Results</span>
                       <span className="text-[10px] font-bold text-gray-400">Click to select</span>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8">
        
        {/* ── Global Summary Bar ─────────────────────────────── */}
        <div className="grid grid-cols-4 gap-4 mb-8">
          {[
            { l: 'Countries Analyzed', v: `${GLOBAL_STATS.totalCountries}`, sub: 'Across all regions', i: Globe, c: 'text-blue-600', bg: 'bg-white' },
            { l: 'Global Avg Risk', v: GLOBAL_STATS.avgRisk.toFixed(1), sub: 'ISCO-weighted composite', i: AlertTriangle, c: 'text-amber-600', bg: 'bg-white' },
            { l: 'Fastest Growing', v: 'AI/ML Engineers', sub: 'ISCO 2513 · +24% YoY', i: TrendingUp, c: 'text-emerald-600', bg: 'bg-white' },
            { l: 'Most At-Risk', v: 'Data Entry Clerks', sub: 'ISCO 4132 · 78% automation', i: Shield, c: 'text-red-600', bg: 'bg-white' },
          ].map((s, i) => (
            <motion.div key={s.l} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
              className={`rounded-2xl p-5 border border-gray-200 shadow-sm ${s.bg}`}>
              <s.i size={18} className={`${s.c} mb-3`} />
              <p className={`text-[22px] font-black ${s.c} leading-none`}>{s.v}</p>
              <p className="text-[11px] font-bold text-gray-500 uppercase tracking-wider mt-1">{s.l}</p>
              <p className="text-[10px] text-gray-400 mt-0.5">{s.sub}</p>
            </motion.div>
          ))}
        </div>

        {/* ── Map ────────────────────────────────────────────── */}
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <RealWorldMap selected={selected} onSelect={handleSelect} />
        </motion.div>

        {/* ── Country Detail Panels ──────────────────────────── */}
        <div ref={detailRef}>
          <AnimatePresence mode="wait">
            {selected && (
              <motion.div key={selected.id} initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.4 }}
                className="mt-12">
                
                {/* Detail Header */}
                <div className="flex items-start justify-between mb-8 bg-white p-6 rounded-3xl border border-gray-200 shadow-sm">
                  <div className="flex items-center gap-5">
                    <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-[22px] font-black"
                      style={{ backgroundColor: `${riskColor(selected.riskScore)}15`, color: riskColor(selected.riskScore), border: `1px solid ${riskColor(selected.riskScore)}30` }}>
                      {selected.riskScore}
                    </div>
                    <div>
                      <h2 className="text-[32px] font-black tracking-tight leading-none text-gray-900">{selected.name}</h2>
                      <div className="flex items-center gap-3 mt-2.5">
                        <span className={`text-[12px] font-black uppercase tracking-wider px-3 py-1.5 rounded-xl border ${riskBg(selected.riskScore)}`}>{riskLabel(selected.riskScore)} Risk</span>
                        <span className="text-[13px] text-gray-500 font-bold">Skill Risk Index: {selected.riskScore}/100</span>
                        <span className="text-gray-300">·</span>
                        <span className="text-[13px] text-emerald-600 font-bold flex items-center gap-1"><Activity size={14} /> Employment: {selected.employmentRate}%</span>
                        <span className="text-gray-300">·</span>
                        <span className="text-[13px] text-blue-600 font-bold flex items-center gap-1"><Users size={14} /> Automation: {selected.automationExposure}%</span>
                      </div>
                    </div>
                  </div>
                  <button onClick={() => setSelected(null)} className="px-4 py-2 rounded-xl bg-gray-100 text-gray-600 hover:bg-gray-200 hover:text-gray-900 font-bold text-sm transition-colors">
                    Close View
                  </button>
                </div>

                {/* The 6 Intelligence Panels */}
                <div className="grid grid-cols-2 gap-6">
                  <LaborOverview d={selected} />
                  <RiskDistribution d={selected} />
                  <HiringDemand d={selected} />
                  <AutomationRisk d={selected} />
                  <SkillGap d={selected} />
                  <PolicyRecommendations d={selected} />
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Empty State */}
          {!selected && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-16 text-center py-16">
              <div className="w-16 h-16 rounded-full bg-blue-50 flex items-center justify-center mx-auto mb-4 border border-blue-100">
                <Sparkles size={28} className="text-blue-500" />
              </div>
              <h3 className="text-[20px] font-bold text-gray-800">Select a country to analyze</h3>
              <p className="text-[14px] text-gray-500 mt-2 max-w-md mx-auto">
                Click a country on the interactive map above to load localized labor insights, automation risk distributions, and AI-generated policy recommendations.
              </p>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
};
