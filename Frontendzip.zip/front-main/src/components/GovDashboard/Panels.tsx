import React from 'react';
import { motion } from 'framer-motion';
import {
  TrendingUp, TrendingDown, AlertTriangle, CheckCircle2,
  Briefcase, Cpu, Brain, Lightbulb, BarChart3, Zap,
  Users, Target, DollarSign, ShieldAlert
} from 'lucide-react';
import type { CountryData } from './data';

const anim = { initial: { opacity: 0, y: 16 }, animate: { opacity: 1, y: 0 } };
const Card: React.FC<{ children: React.ReactNode; delay?: number; className?: string }> = ({ children, delay = 0, className = '' }) => (
  <motion.div {...anim} transition={{ delay }} className={`rounded-2xl border border-gray-200 bg-white shadow-sm p-5 ${className}`}>{children}</motion.div>
);
const Tag: React.FC<{ children: React.ReactNode; color: string }> = ({ children, color }) => (
  <span className={`inline-flex items-center gap-1 rounded-lg px-2.5 py-1 text-[11px] font-bold ${color}`}>{children}</span>
);
const Bar: React.FC<{ pct: number; color: string; label: string; delay?: number }> = ({ pct, color, label, delay = 0 }) => (
  <div className="flex items-center gap-3">
    <span className="w-28 text-[12px] font-bold text-gray-600 truncate">{label}</span>
    <div className="flex-1 h-3 rounded-full bg-gray-100 overflow-hidden">
      <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ delay, duration: 0.8 }} className={`h-full rounded-full ${color}`} />
    </div>
    <span className="text-[12px] font-black text-gray-800 w-10 text-right">{pct}%</span>
  </div>
);

/* ── 1. Labor Market Overview ─────────────────────────── */
export const LaborOverview: React.FC<{ d: CountryData }> = ({ d }) => (
  <Card delay={0.1}>
    <div className="flex items-center gap-2 mb-4"><BarChart3 size={16} className="text-blue-500" /><h3 className="text-[15px] font-black text-gray-900">Labor Market Overview</h3></div>
    <div className="grid grid-cols-3 gap-3 mb-5">
      {[
        { l: 'Employment', v: `${d.employmentRate}%`, c: 'text-emerald-600' },
        { l: 'Avg Wage', v: d.avgWage, c: 'text-blue-600' },
        { l: 'Growth', v: `${d.growthPct > 0 ? '+' : ''}${d.growthPct}%`, c: d.growthPct > 0 ? 'text-emerald-600' : 'text-red-600' },
      ].map(s => (
        <div key={s.l} className="rounded-xl bg-gray-50 p-3 text-center border border-gray-100">
          <p className="text-[10px] font-bold uppercase tracking-widest text-gray-500">{s.l}</p>
          <p className={`text-[20px] font-black mt-1 ${s.c}`}>{s.v}</p>
        </div>
      ))}
    </div>
    <div className="grid grid-cols-2 gap-4">
      <div>
        <p className="text-[11px] font-bold text-emerald-600 uppercase tracking-wider mb-2 flex items-center gap-1"><TrendingUp size={12} /> Growing Sectors</p>
        {d.growingSectors.map(s => <div key={s} className="flex items-center gap-2 py-1"><CheckCircle2 size={11} className="text-emerald-500" /><span className="text-[12px] text-gray-700">{s}</span></div>)}
      </div>
      <div>
        <p className="text-[11px] font-bold text-red-500 uppercase tracking-wider mb-2 flex items-center gap-1"><TrendingDown size={12} /> Declining Sectors</p>
        {d.decliningSectors.map(s => <div key={s} className="flex items-center gap-2 py-1"><AlertTriangle size={11} className="text-red-500" /><span className="text-[12px] text-gray-700">{s}</span></div>)}
      </div>
    </div>
  </Card>
);

/* ── 2. Risk Distribution ────────────────────────────── */
export const RiskDistribution: React.FC<{ d: CountryData }> = ({ d }) => (
  <Card delay={0.15}>
    <div className="flex items-center gap-2 mb-4"><ShieldAlert size={16} className="text-amber-500" /><h3 className="text-[15px] font-black text-gray-900">Risk Distribution (ISCO)</h3></div>
    <div className="space-y-3">
      <Bar pct={d.riskBreakdown.high} color="bg-red-500" label="High Risk" delay={0.2} />
      <Bar pct={d.riskBreakdown.medium} color="bg-amber-500" label="Medium Risk" delay={0.3} />
      <Bar pct={d.riskBreakdown.low} color="bg-emerald-500" label="Low Risk" delay={0.4} />
    </div>
    <div className="mt-4 p-3 rounded-xl bg-gray-50 border border-gray-100">
      <p className="text-[11px] text-gray-600"><span className="font-bold text-gray-900">{d.riskBreakdown.high}%</span> of workforce in high-risk occupations. Immediate intervention recommended for ISCO groups 4, 5, and 9.</p>
    </div>
  </Card>
);

/* ── 3. Hiring & Demand ──────────────────────────────── */
export const HiringDemand: React.FC<{ d: CountryData }> = ({ d }) => (
  <Card delay={0.2}>
    <div className="flex items-center gap-2 mb-4"><Briefcase size={16} className="text-violet-500" /><h3 className="text-[15px] font-black text-gray-900">Hiring Effort & Demand</h3></div>
    <div className="flex items-center gap-4 mb-4">
      <div className="relative w-20 h-20">
        <svg viewBox="0 0 36 36" className="w-full h-full -rotate-90">
          <circle cx="18" cy="18" r="16" fill="none" stroke="#f3f4f6" strokeWidth="3" />
          <motion.circle cx="18" cy="18" r="16" fill="none" stroke="#8b5cf6" strokeWidth="3" strokeLinecap="round"
            strokeDasharray={`${d.hiringEffort} ${100 - d.hiringEffort}`} initial={{ strokeDasharray: '0 100' }}
            animate={{ strokeDasharray: `${d.hiringEffort} ${100 - d.hiringEffort}` }} transition={{ delay: 0.3, duration: 1 }} />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center"><span className="text-[16px] font-black text-gray-900">{d.hiringEffort}</span></div>
      </div>
      <div>
        <p className="text-[13px] font-black text-gray-900">Hiring Effort Index</p>
        <p className="text-[11px] text-gray-600 mt-1">{d.hiringEffort > 70 ? 'Strong demand — employers actively competing for talent.' : d.hiringEffort > 45 ? 'Moderate demand — selective hiring across key sectors.' : 'Low demand — limited new positions opening.'}</p>
      </div>
    </div>
    <p className="text-[11px] font-bold text-gray-500 uppercase tracking-wider mb-2">Top Demand (ISCO)</p>
    {d.topOccupations.map((o, i) => (
      <div key={o} className="flex items-center justify-between py-2 border-b border-gray-100 last:border-0">
        <span className="text-[12px] text-gray-700">{o}</span>
        <Tag color={i === 0 ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-100 text-gray-600'}>{i === 0 ? 'Highest' : `#${i + 1}`}</Tag>
      </div>
    ))}
  </Card>
);

/* ── 4. Automation & Future ─────────────────────────── */
export const AutomationRisk: React.FC<{ d: CountryData }> = ({ d }) => (
  <Card delay={0.25}>
    <div className="flex items-center gap-2 mb-4"><Cpu size={16} className="text-cyan-500" /><h3 className="text-[15px] font-black text-gray-900">Automation & Future Risk</h3></div>
    <div className="flex items-center gap-4 mb-5">
      <div className="flex-1 h-4 rounded-full bg-gray-100 overflow-hidden">
        <motion.div initial={{ width: 0 }} animate={{ width: `${d.automationExposure}%` }} transition={{ delay: 0.4, duration: 1 }}
          className={`h-full rounded-full ${d.automationExposure > 50 ? 'bg-red-500' : d.automationExposure > 30 ? 'bg-amber-500' : 'bg-emerald-500'}`} />
      </div>
      <span className={`text-[18px] font-black ${d.automationExposure > 50 ? 'text-red-500' : d.automationExposure > 30 ? 'text-amber-500' : 'text-emerald-500'}`}>{d.automationExposure}%</span>
    </div>
    <p className="text-[12px] text-gray-600 mb-4">
      {d.automationExposure > 50 ? 'Critical: Over half the workforce faces automation displacement within the next decade.' :
       d.automationExposure > 30 ? 'Moderate: Significant portions of ISCO Groups 4 and 9 face automation pressure.' :
       'Manageable: Workforce has relatively low exposure, but proactive reskilling is still recommended.'}
    </p>
    <p className="text-[11px] font-bold text-gray-500 uppercase tracking-wider mb-2">Most Impacted by AI</p>
    <div className="flex flex-wrap gap-2">
      {['Data Entry (4132)', 'Bookkeeping (4311)', 'Assembly (8211)', 'Cashiers (5230)'].map(o => (
        <Tag key={o} color="bg-red-50 text-red-600 border border-red-200">{o}</Tag>
      ))}
    </div>
  </Card>
);

/* ── 5. Skill Gap ────────────────────────────────────── */
export const SkillGap: React.FC<{ d: CountryData }> = ({ d }) => (
  <Card delay={0.3}>
    <div className="flex items-center gap-2 mb-4"><Brain size={16} className="text-pink-500" /><h3 className="text-[15px] font-black text-gray-900">Skill Gap Analysis</h3></div>
    <div className="grid grid-cols-2 gap-4">
      <div>
        <p className="text-[11px] font-bold text-red-600 uppercase tracking-wider mb-2">Missing in Workforce</p>
        {d.missingSkills.map(s => <div key={s} className="py-1.5 flex items-center gap-2"><AlertTriangle size={11} className="text-red-500 flex-shrink-0" /><span className="text-[12px] text-gray-700">{s}</span></div>)}
      </div>
      <div>
        <p className="text-[11px] font-bold text-cyan-600 uppercase tracking-wider mb-2">Emerging & Required</p>
        {d.emergingSkills.map(s => <div key={s} className="py-1.5 flex items-center gap-2"><Zap size={11} className="text-cyan-500 flex-shrink-0" /><span className="text-[12px] text-gray-700">{s}</span></div>)}
      </div>
    </div>
    <div className="mt-4 p-3 rounded-xl bg-cyan-50 border border-cyan-100">
      <p className="text-[11px] text-cyan-800"><Target size={11} className="inline mr-1" />Transition pathway: <span className="font-bold text-cyan-700">ISCO 2513 → AI/ML Roles</span> — retraining window is 6–12 months with existing STEM base.</p>
    </div>
  </Card>
);

/* ── 6. AI Policy Recommendations ────────────────────── */
export const PolicyRecommendations: React.FC<{ d: CountryData }> = ({ d }) => (
  <Card delay={0.35} className="border-amber-200 bg-amber-50">
    <div className="flex items-center gap-2 mb-5"><Lightbulb size={18} className="text-amber-500" /><h3 className="text-[16px] font-black text-gray-900">AI Policy Recommendations</h3><Tag color="bg-amber-100 text-amber-700">Critical</Tag></div>
    <div className="space-y-4">
      {d.aiPolicies.map((p, i) => (
        <motion.div key={i} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.5 + i * 0.1 }}
          className="rounded-xl bg-white border border-gray-100 p-4 hover:border-amber-300 transition-colors shadow-sm">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-amber-100 flex items-center justify-center flex-shrink-0 mt-0.5">
              <span className="text-[13px] font-black text-amber-600">{i + 1}</span>
            </div>
            <div className="flex-1">
              <h4 className="text-[14px] font-black text-gray-900 mb-2">{p.title}</h4>
              <div className="space-y-2">
                <div className="flex gap-2"><span className="text-[10px] font-black text-red-500 uppercase tracking-wider mt-0.5 flex-shrink-0">WHY</span><p className="text-[12px] text-gray-600 leading-5">{p.why}</p></div>
                <div className="flex gap-2"><span className="text-[10px] font-black text-emerald-600 uppercase tracking-wider mt-0.5 flex-shrink-0">IMPACT</span><p className="text-[12px] text-gray-600 leading-5">{p.impact}</p></div>
              </div>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  </Card>
);
