import React, { useEffect, useRef } from 'react';
import { MapContainer, TileLayer, GeoJSON, Tooltip, ZoomControl } from 'react-leaflet';
import type { Map as LMap, Layer, GeoJSONOptions } from 'leaflet';
import type { Feature } from 'geojson';
import type { CountryData } from './data';
import { COUNTRIES } from './data';
import 'leaflet/dist/leaflet.css';

/* ── ISO-3166-1 Alpha-3 → Our country IDs ────────────────── */
const ISO3_TO_ID: Record<string, string> = {
  USA: 'US', IND: 'IN', DEU: 'DE', BRA: 'BR', NGA: 'NG', JPN: 'JP',
  GBR: 'GB', CAN: 'CA', AUS: 'AU', FRA: 'FR', ITA: 'IT', CHN: 'CN',
  ZAF: 'ZA', MEX: 'MX', KOR: 'KR'
};

/* ── Risk colour mapping ─────────────────────────────────── */
const riskColor = (score: number) =>
  score >= 60 ? '#ef4444' : score >= 40 ? '#f59e0b' : '#22c55e';

const getCountryId = (feature: Feature): string | null => {
  const iso3 = feature.properties?.ISO_A3 || feature.properties?.iso_a3 || '';
  return ISO3_TO_ID[iso3] || null;
};

const getCountryData = (feature: Feature): CountryData | null => {
  const id = getCountryId(feature);
  return id ? COUNTRIES.find(c => c.id === id) || null : null;
};

/* ── GeoJSON style per feature ───────────────────────────── */
const featureStyle = (selectedId: string | null) => (feature?: Feature): any => {
  const data = feature ? getCountryData(feature) : null;
  const id = feature ? getCountryId(feature) : null;
  const isSelected = id && id === selectedId;

  if (!data) {
    return {
      fillColor: '#1e2d45',
      fillOpacity: 0.6,
      color: '#2a3f60',
      weight: 0.5,
    };
  }

  return {
    fillColor: riskColor(data.riskScore),
    fillOpacity: isSelected ? 0.85 : 0.5,
    color: isSelected ? '#ffffff' : '#1a2840',
    weight: isSelected ? 2 : 0.8,
    dashArray: isSelected ? '' : '',
  };
};

interface RealWorldMapProps {
  selected: CountryData | null;
  onSelect: (c: CountryData) => void;
}

export const RealWorldMap: React.FC<RealWorldMapProps> = ({ selected, onSelect }) => {
  const mapRef = useRef<LMap | null>(null);
  const geoJsonRef = useRef<any>(null);
  const [geoData, setGeoData] = React.useState<any>(null);

  /* ── Fetch world GeoJSON from public CDN ────────────────── */
  useEffect(() => {
    fetch('https://raw.githubusercontent.com/datasets/geo-countries/master/data/countries.geojson')
      .then(r => r.json())
      .then(setGeoData)
      .catch(() => {
        // Fallback: try alternative CDN
        fetch('https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json').catch(() => {});
      });
  }, []);

  /* ── Refresh styles when selection changes ───────────────── */
  useEffect(() => {
    if (geoJsonRef.current) {
      geoJsonRef.current.setStyle(featureStyle(selected?.id || null));
    }
  }, [selected]);

  /* ── Fly to country on selection ────────────────────────── */
  const COUNTRY_CENTERS: Record<string, [number, number]> = {
    US: [39, -96], IN: [21, 79], DE: [51, 10],
    BR: [-14, -51], NG: [9, 8], JP: [36, 138],
    GB: [55, -3], CA: [56, -106], AU: [-25, 133],
    FR: [46, 2], IT: [41, 12], CN: [35, 104],
    ZA: [-30, 25], MX: [23, -102], KR: [36, 128]
  };

  useEffect(() => {
    if (selected && mapRef.current) {
      const center = COUNTRY_CENTERS[selected.id];
      if (center) {
        mapRef.current.flyTo(center, 5, { duration: 1.2 });
      }
    }
  }, [selected]);

  const onEachFeature = (feature: Feature, layer: Layer) => {
    const data = getCountryData(feature);
    const name = feature.properties?.ADMIN || feature.properties?.name || 'Unknown';

    if (data) {
      // @ts-ignore
      layer.on({
        mouseover: (e: any) => {
          e.target.setStyle({ fillOpacity: 0.85, weight: 2, color: '#ffffff' });
        },
        mouseout: (e: any) => {
          if (geoJsonRef.current) {
            geoJsonRef.current.resetStyle(e.target);
          }
        },
        click: () => onSelect(data),
      });
    }
  };

  return (
    <div className="relative w-full rounded-3xl overflow-hidden border border-white/[0.08] shadow-2xl" style={{ height: '500px' }}>
      <MapContainer
        center={[20, 0]}
        zoom={2}
        minZoom={2}
        maxZoom={8}
        style={{ height: '100%', width: '100%', background: '#060e1f' }}
        ref={mapRef}
        zoomControl={false}
        scrollWheelZoom={true}
        worldCopyJump={false}
        maxBounds={[[-90, -180], [90, 180]]}
        maxBoundsViscosity={1.0}
      >
        {/* Dark Map Tiles (CartoDB Dark Matter) */}
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
          attribution='&copy; <a href="https://carto.com/">CARTO</a>'
          subdomains="abcd"
          maxZoom={20}
        />

        {/* Country GeoJSON with risk colors */}
        {geoData && (
          <GeoJSON
            ref={geoJsonRef}
            data={geoData}
            style={featureStyle(selected?.id || null)}
            onEachFeature={onEachFeature}
          >
            {/* Tooltips are handled per-layer via onEachFeature */}
          </GeoJSON>
        )}

        <ZoomControl position="bottomright" />
      </MapContainer>

      {/* Overlay: Legend */}
      <div className="absolute bottom-10 left-4 z-[1000] flex flex-col gap-1.5 bg-black/70 backdrop-blur-md rounded-xl px-4 py-3 border border-white/[0.08]">
        <p className="text-[10px] font-black uppercase tracking-widest text-white/40 mb-1">Skill Risk Index</p>
        {[['#22c55e', 'Low Risk (0–39)'], ['#f59e0b', 'Medium Risk (40–59)'], ['#ef4444', 'High Risk (60+)'], ['#1e2d45', 'No Data']].map(([c, l]) => (
          <div key={l} className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-sm flex-shrink-0" style={{ backgroundColor: c }} />
            <span className="text-[11px] font-bold text-white/60">{l}</span>
          </div>
        ))}
      </div>

      {/* Overlay: Top Label */}
      <div className="absolute top-4 left-4 z-[1000] flex items-center gap-2 bg-black/70 backdrop-blur-md rounded-xl px-3 py-2 border border-white/[0.08]">
        <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
        <span className="text-[11px] font-bold text-white/60">Live ILO · ISCO Classification · Click a country</span>
      </div>

      {/* Overlay: Loading state */}
      {!geoData && (
        <div className="absolute inset-0 z-[999] flex items-center justify-center bg-[#060e1f]/80 backdrop-blur-sm">
          <div className="text-center">
            <div className="w-10 h-10 border-2 border-blue-500/30 border-t-blue-500 rounded-full animate-spin mx-auto mb-3" />
            <p className="text-[13px] font-bold text-white/50">Loading world map…</p>
          </div>
        </div>
      )}
    </div>
  );
};
