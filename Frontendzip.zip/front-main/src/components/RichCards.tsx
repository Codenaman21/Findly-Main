import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import {
  Briefcase, MapPin, DollarSign, ExternalLink, AlertTriangle,
  CheckCircle2, TrendingUp, Play, Pause, BookOpen, Wrench, Globe,
  Route, Building2, Navigation, Layers3, GraduationCap, Mail,
  Phone, UserRound, Laptop, MessageSquareText, ArrowRight,
} from 'lucide-react';
import type { Opportunity, Resource, RiskAnalysis, RoadmapStep, SkillSet } from '../types';
import clsx from 'clsx';

/* ── shared section title ────────────────────────────────── */
const SectionTitle: React.FC<{ icon: React.ElementType; title: string; eyebrow?: string }> = ({ icon: Icon, title, eyebrow }) => (
  <div className="mb-3 flex items-end justify-between gap-3">
    <div>
      {eyebrow && <p className="mb-1 text-xs font-medium text-[#9a9a9a]">{eyebrow}</p>}
      <h3 className="flex items-center gap-2 text-[14px] font-semibold text-[#1a1a1a]">
        <Icon size={15} className="text-[#6b6b6b]" /> {title}
      </h3>
    </div>
  </div>
);

const Card: React.FC<{ children: React.ReactNode; delay?: number; className?: string }> = ({ children, delay = 0, className = '' }) => (
  <motion.div
    initial={{ opacity: 0, y: 8 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay }}
    className={`rounded-2xl border border-black/[0.07] bg-white p-4 shadow-sm ${className}`}
  >
    {children}
  </motion.div>
);

/* ── Plan summary card ───────────────────────────────────── */
export const PlanSystemCard: React.FC<{
  role?: string; risk?: RiskAnalysis; opportunityCount?: number; roadmapCount?: number;
}> = ({ role, risk, opportunityCount = 0, roadmapCount = 0 }) => (
  <Card>
    <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
      <div>
        <p className="text-[11px] font-semibold uppercase tracking-widest text-[#9a9a9a]">Skill-first direction</p>
        <h3 className="mt-1 text-[18px] font-bold text-[#1a1a1a]">{role || 'Personalised opportunity plan'}</h3>
        <p className="mt-1.5 max-w-md text-[13px] leading-5 text-[#6b6b6b]">
          Focus on this lane first — it can be proven with projects even without a degree.
        </p>
      </div>
      {risk && (
        <span className={clsx('w-fit flex-shrink-0 rounded-full border px-3 py-1 text-[11px] font-bold', {
          'border-emerald-200 bg-emerald-50 text-emerald-700': risk.level === 'Low',
          'border-amber-200 bg-amber-50 text-amber-700': risk.level === 'Medium',
          'border-red-200 bg-red-50 text-red-700': risk.level === 'High',
        })}>
          {risk.level} risk
        </span>
      )}
    </div>
    <div className="mt-4 grid grid-cols-3 gap-2 text-sm">
      {[
        { label: 'Roles found', value: String(opportunityCount || 1) },
        { label: 'Roadmap',     value: `${roadmapCount || 3} months` },
        { label: 'Priority',    value: risk?.level || 'Clear' },
      ].map(s => (
        <div key={s.label} className="rounded-xl bg-[#f8f7f5] p-3">
          <span className="block text-[11px] text-[#9a9a9a]">{s.label}</span>
          <strong className="text-[13px] text-[#1a1a1a]">{s.value}</strong>
        </div>
      ))}
    </div>
  </Card>
);

/* ── Opportunities ───────────────────────────────────────── */
export const OpportunitiesList: React.FC<{ ops: Opportunity[] }> = ({ ops }) => (
  <Card delay={0.05}>
    <SectionTitle icon={TrendingUp} title="Opportunities" eyebrow="Walk-in, email HR, contact, or freelance" />
    <div className="mb-3 grid grid-cols-4 gap-2">
      {[
        { icon: UserRound, label: 'Walk-in',  cls: 'text-emerald-700 bg-emerald-50 border-emerald-200' },
        { icon: Mail,      label: 'Email HR', cls: 'text-blue-700 bg-blue-50 border-blue-200' },
        { icon: Phone,     label: 'Contact',  cls: 'text-amber-700 bg-amber-50 border-amber-200' },
        { icon: Laptop,    label: 'Freelance',cls: 'text-violet-700 bg-violet-50 border-violet-200' },
      ].map(item => (
        <div key={item.label} className={`flex items-center justify-center gap-1.5 rounded-xl border px-2 py-2 text-[11px] font-semibold ${item.cls}`}>
          <item.icon size={12} /> {item.label}
        </div>
      ))}
    </div>
    <div className="grid gap-2.5">
      {ops.map((op, idx) => (
        <div key={op.id} className="rounded-xl border border-black/[0.07] bg-[#f8f7f5] p-3">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#1a1a1a] text-[12px] font-bold text-white">
                {idx + 1}
              </div>
              <div>
                <p className="text-[13px] font-semibold text-[#1a1a1a]">{op.role}</p>
                <div className="mt-0.5 flex flex-wrap gap-x-3 gap-y-0.5 text-[11px] text-[#9a9a9a]">
                  <span className="flex items-center gap-1"><MapPin size={10} /> {op.location}</span>
                  <span className="flex items-center gap-1"><DollarSign size={10} /> {op.salary}</span>
                  <span className="flex items-center gap-1"><Building2 size={10} /> Portfolio friendly</span>
                </div>
              </div>
            </div>
            <div className="flex gap-2">
              <span className="rounded-lg border border-emerald-200 bg-emerald-50 px-2.5 py-1 text-[11px] font-semibold text-emerald-700">Good fit</span>
              <button className="flex items-center gap-1.5 rounded-lg border border-black/[0.08] bg-white px-2.5 py-1 text-[11px] font-medium text-[#6b6b6b] transition hover:bg-[#f0ede8]">
                View <ExternalLink size={10} />
              </button>
            </div>
          </div>
          <div className="mt-2.5 grid grid-cols-4 gap-1.5 border-t border-black/[0.06] pt-2.5">
            {[
              { icon: UserRound, label: 'Walk-in',  cls: 'text-emerald-700 bg-emerald-50 hover:bg-emerald-100' },
              { icon: Mail,      label: 'Draft email',cls:'text-blue-700 bg-blue-50 hover:bg-blue-100' },
              { icon: Phone,     label: 'Contact',  cls: 'text-amber-700 bg-amber-50 hover:bg-amber-100' },
              { icon: Laptop,    label: 'Freelance',cls: 'text-violet-700 bg-violet-50 hover:bg-violet-100' },
            ].map(b => (
              <button key={b.label} className={`flex items-center justify-center gap-1 rounded-lg py-1.5 text-[11px] font-semibold transition ${b.cls}`}>
                <b.icon size={11} /> {b.label}
              </button>
            ))}
          </div>
        </div>
      ))}
    </div>
  </Card>
);

/* ── Skill analysis ──────────────────────────────────────── */
export const SkillAnalysisCard: React.FC<{ skills: SkillSet }> = ({ skills }) => (
  <Card delay={0.1}>
    <SectionTitle icon={CheckCircle2} title="Skill analysis" eyebrow="Convert skills into employable proof" />
    <div className="mb-3 grid grid-cols-3 gap-2">
      {[['Skill','What you know'],['Proof','Projects employers see'],['Pitch','Email, interview, walk-in']].map(([l, v]) => (
        <div key={l} className="rounded-xl bg-[#f8f7f5] p-2.5">
          <p className="text-[10px] font-bold text-[#1a1a1a]">{l}</p>
          <p className="mt-0.5 text-[11px] text-[#6b6b6b]">{v}</p>
        </div>
      ))}
    </div>
    <div className="grid gap-3 sm:grid-cols-2">
      <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-3">
        <div className="mb-2 flex items-center justify-between">
          <p className="text-[12px] font-bold text-emerald-800">Strengths</p>
          <span className="rounded-full bg-emerald-200 px-2 py-0.5 text-[10px] font-bold text-emerald-800">{skills.present.length}</span>
        </div>
        <div className="space-y-1.5">
          {skills.present.map(s => (
            <div key={s} className="flex items-center gap-1.5 text-[12px] text-emerald-800">
              <CheckCircle2 size={12} className="text-emerald-600 flex-shrink-0" /> {s}
            </div>
          ))}
        </div>
      </div>
      <div className="rounded-xl border border-amber-200 bg-amber-50 p-3">
        <div className="mb-2 flex items-center justify-between">
          <p className="text-[12px] font-bold text-amber-800">To learn</p>
          <span className="rounded-full bg-amber-200 px-2 py-0.5 text-[10px] font-bold text-amber-800">{skills.missing.length}</span>
        </div>
        <div className="space-y-1.5">
          {skills.missing.map(s => (
            <div key={s} className="flex items-center gap-1.5 text-[12px] text-amber-800">
              <AlertTriangle size={12} className="text-amber-600 flex-shrink-0" /> {s}
            </div>
          ))}
        </div>
      </div>
    </div>
    <div className="mt-3 rounded-xl border border-black/[0.07] bg-[#f8f7f5] p-3">
      <div className="mb-2 flex items-center justify-between">
        <p className="text-[12px] font-semibold text-[#1a1a1a]">Job readiness</p>
        <span className="text-[12px] font-bold text-[#1a1a1a]">62%</span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-black/[0.06]">
        <motion.div initial={{ width: 0 }} animate={{ width: '62%' }} transition={{ delay: 0.5, duration: 0.8 }}
          className="h-full rounded-full bg-[#1a1a1a]" />
      </div>
      <p className="mt-2 text-[11px] text-[#6b6b6b]">Build 2 proof projects to reach 85%+ and get noticed by employers.</p>
    </div>
  </Card>
);

/* ── Risk meter ──────────────────────────────────────────── */
export const RiskMeter: React.FC<{ risk: RiskAnalysis }> = ({ risk }) => {
  const width = risk.level === 'Low' ? '28%' : risk.level === 'Medium' ? '60%' : '88%';
  const cls = risk.level === 'Low'
    ? { bar: 'bg-emerald-500', badge: 'border-emerald-200 bg-emerald-50 text-emerald-700' }
    : risk.level === 'Medium'
    ? { bar: 'bg-amber-500', badge: 'border-amber-200 bg-amber-50 text-amber-700' }
    : { bar: 'bg-red-500', badge: 'border-red-200 bg-red-50 text-red-700' };
  return (
    <Card delay={0.15}>
      <div className="mb-3 flex items-center justify-between">
        <h3 className="text-[14px] font-semibold text-[#1a1a1a]">Risk profile</h3>
        <span className={`rounded-full border px-2.5 py-0.5 text-[11px] font-bold ${cls.badge}`}>{risk.level}</span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-black/[0.06]">
        <motion.div initial={{ width: 0 }} animate={{ width }} transition={{ delay: 0.3, duration: 0.7 }}
          className={`h-full rounded-full ${cls.bar}`} />
      </div>
      <p className="mt-2.5 text-[12px] leading-5 text-[#6b6b6b]">{risk.explanation}</p>
    </Card>
  );
};

/* ── Roadmap timeline ────────────────────────────────────── */
export const RoadmapTimeline: React.FC<{ steps: RoadmapStep[] }> = ({ steps }) => (
  <Card delay={0.2}>
    <SectionTitle icon={Route} title="Execution roadmap" eyebrow="Learn → build proof → apply → freelance" />
    <div className="space-y-2.5">
      {steps.map((step, idx) => (
        <div key={idx} className="flex gap-3 rounded-xl border border-black/[0.07] bg-[#f8f7f5] p-3">
          <div className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-xl border border-black/[0.1] bg-white text-[12px] font-bold text-[#1a1a1a]">
            M{step.month}
          </div>
          <div>
            <p className="text-[13px] font-semibold text-[#1a1a1a]">{step.title}</p>
            <p className="mt-0.5 text-[12px] leading-5 text-[#6b6b6b]">{step.description}</p>
          </div>
          <span className="ml-auto flex-shrink-0 self-start rounded-full border border-black/[0.07] bg-white px-2.5 py-0.5 text-[10px] font-semibold text-[#6b6b6b]">
            Step {idx + 1}
          </span>
        </div>
      ))}
    </div>
    <div className="mt-3 grid grid-cols-3 gap-2">
      {['Learn basics', 'Build proof', 'Apply + freelance'].map(p => (
        <div key={p} className="rounded-xl border border-black/[0.07] bg-[#f8f7f5] px-3 py-2 text-center text-[11px] font-semibold text-[#1a1a1a]">
          {p}
        </div>
      ))}
    </div>
  </Card>
);

/* ── Resources grid ──────────────────────────────────────── */
export const ResourcesGrid: React.FC<{ resources: Resource[] }> = ({ resources }) => (
  <Card delay={0.25}>
    <SectionTitle icon={GraduationCap} title="Recommended resources" eyebrow="Learn → practice → ship proof → reach out" />
    <div className="mb-3 grid grid-cols-3 gap-2">
      {[['1','Learn','React basics'],['2','Practice','Mini projects'],['3','Ship','Portfolio proof']].map(([n, l, d]) => (
        <div key={l} className="rounded-xl bg-[#f8f7f5] p-2.5">
          <div className="mb-1.5 flex h-6 w-6 items-center justify-center rounded-lg bg-[#1a1a1a] text-[10px] font-bold text-white">{n}</div>
          <p className="text-[12px] font-semibold text-[#1a1a1a]">{l}</p>
          <p className="mt-0.5 text-[10px] text-[#9a9a9a]">{d}</p>
        </div>
      ))}
    </div>
    <div className="grid gap-2 sm:grid-cols-2">
      {resources.map(res => (
        <a key={res.id} href={res.url} target="_blank" rel="noreferrer"
          className="group flex items-center gap-3 rounded-xl border border-black/[0.07] bg-[#f8f7f5] p-3 transition hover:border-black/20 hover:bg-white">
          <div className="rounded-xl bg-white p-2 text-[#6b6b6b] shadow-sm group-hover:text-[#1a1a1a]">
            {res.type === 'Course' ? <BookOpen size={14} /> : res.type === 'Tool' ? <Wrench size={14} /> : <Globe size={14} />}
          </div>
          <div className="flex-1 min-w-0">
            <p className="truncate text-[12px] font-semibold text-[#1a1a1a]">{res.title}</p>
            <p className="text-[10px] text-[#9a9a9a]">{res.type}</p>
          </div>
          <ExternalLink size={12} className="text-[#b0b0b0] group-hover:text-[#1a1a1a]" />
        </a>
      ))}
    </div>
  </Card>
);

/* ── Jobs map card ───────────────────────────────────────── */
export const JobsMapCard: React.FC<{ points: import('../types').MapPoint[] }> = ({ points }) => (
  <Card delay={0.08}>
    <SectionTitle icon={MapPin} title="Nearby opportunities map" eyebrow="Walk-in interviews, email leads, freelance gigs" />
    <div className="grid gap-3 lg:grid-cols-[1fr_200px]">
      <div className="relative h-52 w-full overflow-hidden rounded-xl border border-black/[0.07] bg-[#e8f4f0]">
        <div className="absolute inset-0 opacity-30 bg-[linear-gradient(30deg,transparent_35%,rgba(0,0,0,0.06)_36%,transparent_37%),linear-gradient(90deg,rgba(0,0,0,0.04)_1px,transparent_1px),linear-gradient(rgba(0,0,0,0.04)_1px,transparent_1px)] bg-[size:120px_80px,28px_28px,28px_28px]" />
        <div className="absolute left-[20%] top-0 h-full w-2 rotate-[25deg] bg-white/60" />
        <div className="absolute left-[55%] top-0 h-full w-2 -rotate-[15deg] bg-white/60" />
        <div className="absolute left-0 top-[40%] h-2 w-full rotate-[3deg] bg-white/60" />
        {points.map((p, i) => (
          <div key={p.id} className="group absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center cursor-pointer"
            style={{ top: `${p.lat}%`, left: `${p.lng}%` }}>
            <div className="relative flex h-8 w-8 items-center justify-center rounded-full bg-[#1a1a1a] text-white shadow-lg">
              <MapPin size={14} fill="currentColor" />
              <span className={`absolute -right-1 -top-1 rounded-full px-1.5 py-0.5 text-[8px] font-bold text-white ${
                i === 0 ? 'bg-emerald-500' : i === 1 ? 'bg-blue-500' : 'bg-violet-500'
              }`}>
                {i === 0 ? 'Walk-in' : i === 1 ? 'Email' : 'Gig'}
              </span>
            </div>
            <div className="absolute top-full z-10 mt-1.5 hidden whitespace-nowrap rounded-xl border border-black/[0.08] bg-white px-2.5 py-1.5 text-[11px] font-medium text-[#1a1a1a] shadow-lg group-hover:block">
              {p.role}
            </div>
          </div>
        ))}
        <div className="absolute left-3 top-3 flex items-center gap-1.5 rounded-xl border border-black/[0.08] bg-white px-2.5 py-1.5 text-[11px] font-medium text-[#1a1a1a]">
          <Navigation size={11} /> Nearby job map
        </div>
      </div>
      <div className="grid gap-2 content-start">
        {points.map((p, i) => (
          <div key={p.id} className="rounded-xl border border-black/[0.07] bg-[#f8f7f5] p-3">
            <p className={`text-[10px] font-bold ${i===0?'text-emerald-700':i===1?'text-blue-700':'text-violet-700'}`}>
              {i === 0 ? 'Walk-in' : i === 1 ? 'Email lead' : 'Freelance'}
            </p>
            <p className="mt-0.5 text-[12px] font-semibold text-[#1a1a1a]">{p.role}</p>
            <p className="mt-0.5 text-[10px] text-[#9a9a9a]">{i + 2} km · Portfolio accepted</p>
            <div className="mt-2 grid grid-cols-2 gap-1.5">
              <button className="rounded-lg bg-white border border-black/[0.07] py-1 text-[10px] font-semibold text-[#6b6b6b] hover:bg-[#f0ede8]">Details</button>
              <button className={`rounded-lg py-1 text-[10px] font-semibold text-white ${i===0?'bg-emerald-600':i===1?'bg-blue-600':'bg-violet-600'}`}>
                {i === 0 ? 'Visit' : i === 1 ? 'Email' : 'Pitch'}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  </Card>
);

/* ── Voice assistant ─────────────────────────────────────── */
export const VoiceAssistantPlayer: React.FC<{ text: string }> = ({ text }) => {
  const [isPlaying, setIsPlaying] = useState(false);

  const handlePlay = () => {
    if (!('speechSynthesis' in window)) return;
    if (isPlaying) { window.speechSynthesis.cancel(); setIsPlaying(false); return; }
    const utterance = new SpeechSynthesisUtterance(text);
    const voices = window.speechSynthesis.getVoices();
    const voice = voices.find(v => v.lang.includes('en') && v.name.includes('Google')) || voices[0];
    if (voice) utterance.voice = voice;
    utterance.pitch = 1; utterance.rate = 1.05;
    utterance.onend = () => setIsPlaying(false);
    utterance.onerror = () => setIsPlaying(false);
    window.speechSynthesis.speak(utterance);
    setIsPlaying(true);
  };

  useEffect(() => () => { if ('speechSynthesis' in window) window.speechSynthesis.cancel(); }, []);

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }} className="flex justify-end">
      <button onClick={handlePlay}
        className="flex items-center gap-2 rounded-full border border-black/[0.08] bg-white px-3.5 py-1.5 text-[12px] font-medium text-[#6b6b6b] shadow-sm transition hover:border-black/20 hover:text-[#1a1a1a]">
        {isPlaying ? <Pause size={13} /> : <Play size={13} />}
        {isPlaying ? 'Playing…' : 'Listen to explanation'}
      </button>
    </motion.div>
  );
};

/* ── Legacy export kept for compatibility ────────────────── */
export const RoleCard: React.FC<{ role: string }> = ({ role }) => (
  <Card>
    <div className="flex items-center gap-3">
      <div className="rounded-xl bg-[#f0ede8] p-2.5 text-[#6b6b6b]"><Briefcase size={20} /></div>
      <div>
        <p className="text-[11px] text-[#9a9a9a]">Best suited role</p>
        <p className="text-[15px] font-bold text-[#1a1a1a]">{role}</p>
      </div>
    </div>
  </Card>
);

/* ── Dynamic Backend Cards ────────────────────────────────── */
export const BackendOpportunitiesCard: React.FC<{ opsData: any }> = ({ opsData }) => (
  <Card delay={0.05} className="mt-2">
    <SectionTitle icon={TrendingUp} title="Career Opportunities" eyebrow={`Primary focus: ${opsData.primary_tier || 'Opportunities'}`} />
    <p className="mb-4 text-[13px] text-[#6b6b6b] leading-relaxed">{opsData.summary}</p>
    
    {opsData.jobs?.jobs?.length > 0 && (
      <div className="mb-4">
        <h4 className="text-[12px] font-bold text-[#1a1a1a] mb-2 uppercase tracking-wide flex items-center gap-2"><Briefcase size={12}/> Standard Jobs</h4>
        <div className="grid gap-2">
          {opsData.jobs.jobs.map((job: any, i: number) => (
            <div key={i} className="rounded-xl border border-black/[0.07] bg-[#f8f7f5] p-3 flex justify-between items-center">
              <div className="flex-1 pr-4">
                <p className="text-[13px] font-bold text-[#1a1a1a] leading-tight">{job.title}</p>
                <p className="text-[11px] text-[#9a9a9a] mt-1">{job.company} · {job.location}</p>
              </div>
              {job.link && (
                 <a href={job.link} target="_blank" rel="noreferrer" className="flex-shrink-0 flex items-center gap-1.5 rounded-lg bg-blue-50 text-blue-600 px-3 py-1.5 text-[11px] font-bold hover:bg-blue-100 transition">
                   Apply <ExternalLink size={12} />
                 </a>
              )}
            </div>
          ))}
        </div>
      </div>
    )}

    {opsData.freelance?.opportunities?.length > 0 && (
      <div className="mb-4">
        <h4 className="text-[12px] font-bold text-[#1a1a1a] mb-2 uppercase tracking-wide flex items-center gap-2"><Laptop size={12}/> Freelance Platforms</h4>
        <div className="flex flex-wrap gap-2">
          {opsData.freelance.opportunities.map((f: any, i: number) => (
            <React.Fragment key={i}>
              {f.link ? (
                <a href={f.link} target="_blank" rel="noreferrer" className="rounded-xl border border-violet-200 bg-violet-50 text-violet-700 px-3 py-2 text-[12px] font-bold hover:bg-violet-100 transition flex items-center gap-2">
                  {f.platform} <ExternalLink size={12} />
                </a>
              ) : (
                <span className="rounded-xl border border-gray-200 bg-gray-50 text-gray-700 px-3 py-2 text-[12px] font-bold flex items-center gap-2">
                  {f.tag?.replace('_', ' ')}
                </span>
              )}
            </React.Fragment>
          ))}
        </div>
      </div>
    )}

    {opsData.walkin?.places?.length > 0 && (
      <div>
        <h4 className="text-[12px] font-bold text-[#1a1a1a] mb-2 uppercase tracking-wide flex items-center gap-2"><MapPin size={12}/> Walk-in Locations</h4>
        <div className="grid grid-cols-2 gap-2">
          {opsData.walkin.places.map((w: any, i: number) => (
            <a key={i} href={w.map_link} target="_blank" rel="noreferrer" className="rounded-xl border border-emerald-200 bg-emerald-50 p-3 hover:bg-emerald-100 transition group block">
              <p className="text-[12px] font-bold text-emerald-800 capitalize">{w.type}</p>
              <p className="text-[10px] text-emerald-600 mt-0.5 flex items-center justify-between">
                Near {opsData.walkin.location} <ArrowRight size={10} className="opacity-0 group-hover:opacity-100 transition" />
              </p>
            </a>
          ))}
        </div>
      </div>
    )}
  </Card>
);

export const BackendLearningPlanCard: React.FC<{ plan: any }> = ({ plan }) => (
  <Card delay={0.05} className="mt-2">
    <SectionTitle icon={GraduationCap} title="Custom Learning Plan" eyebrow={`Role: ${plan.role}`} />
    
    <div className="mb-4 rounded-xl bg-blue-50 p-4 border border-blue-100">
      <div className="flex justify-between items-center mb-2">
        <p className="text-[12px] font-bold text-blue-800 uppercase tracking-wide">Progress: {plan.stage}</p>
        <p className="text-[14px] font-black text-blue-600">{plan.progress?.percent_complete || 0}%</p>
      </div>
      <div className="h-2 w-full bg-blue-200 rounded-full overflow-hidden">
        <motion.div initial={{ width: 0 }} animate={{ width: `${plan.progress?.percent_complete || 0}%` }} transition={{ duration: 1, ease: "easeOut" }} className="h-full bg-blue-600 rounded-full" />
      </div>
      <p className="text-[11px] text-blue-600/80 mt-1.5 font-medium">You have {plan.progress?.user_has || 0} of {plan.progress?.total_required || 0} required skills.</p>
    </div>

    {plan.focus_skills?.length > 0 && (
      <div className="mb-4">
        <h4 className="text-[12px] font-bold text-[#1a1a1a] mb-2 uppercase tracking-wide flex items-center gap-2"><Layers3 size={12}/> Focus Skills</h4>
        <div className="flex flex-wrap gap-2">
          {plan.focus_skills.map((s: string, i: number) => (
            <span key={i} className="rounded-lg bg-[#f8f7f5] border border-black/[0.05] px-3 py-1.5 text-[12px] font-bold text-[#1a1a1a] capitalize">
              {s}
            </span>
          ))}
        </div>
      </div>
    )}

    {plan.resources && Object.keys(plan.resources).length > 0 && (
      <div>
        <h4 className="text-[12px] font-bold text-[#1a1a1a] mb-2 uppercase tracking-wide flex items-center gap-2"><BookOpen size={12}/> Resources</h4>
        <div className="grid gap-2">
          {Object.entries(plan.resources).map(([skill, links]: [string, any], i: number) => (
            <div key={i} className="rounded-xl border border-black/[0.07] p-3">
              <p className="text-[12px] font-bold text-[#1a1a1a] capitalize mb-2">{skill}</p>
              <div className="flex flex-wrap gap-1.5">
                {Object.entries(links).map(([platform, url]: [string, any], j: number) => (
                  <a key={j} href={url} target="_blank" rel="noreferrer" className="rounded-md bg-gray-50 border border-gray-200 px-2 py-1 text-[10px] font-bold text-gray-600 hover:bg-gray-100 transition">
                    {platform}
                  </a>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    )}
  </Card>
);
