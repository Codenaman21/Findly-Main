import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Sparkles, ArrowRight, Briefcase, MapPin, BookOpen,
  TrendingUp, CheckCircle, Star, Zap, Shield, Users,
  ChevronRight, Globe,
} from 'lucide-react';

interface LandingScreenProps {
  onEnterChat: () => void;
  onOpenGov?: () => void;
}

const FEATURES = [
  {
    icon: Briefcase,
    title: 'Instant job matches',
    desc: 'Get roles aligned to exactly what you know today — no fluff, no degree filter.',
  },
  {
    icon: TrendingUp,
    title: 'Skill gap analysis',
    desc: 'See a clear breakdown of what you have and precisely what you need to get hired.',
  },
  {
    icon: BookOpen,
    title: 'Month-by-month roadmap',
    desc: 'A personal execution plan with curated resources — learn, build proof, then apply.',
  },
  {
    icon: MapPin,
    title: 'Local opportunities',
    desc: 'Walk-in interviews, email leads, and freelance gigs near you right now.',
  },
  {
    icon: Shield,
    title: 'No degree required',
    desc: 'Proof-of-work routes that bypass traditional filters. Skills first, always.',
  },
  {
    icon: Zap,
    title: 'AI-powered in seconds',
    desc: 'No forms, no waiting. Describe yourself and get a full career plan instantly.',
  },
];

const TESTIMONIALS = [
  {
    name: 'Riya Sharma',
    role: 'Junior Frontend Developer',
    company: 'Hired at a Mumbai startup',
    text: 'I described my skills in one message and Findy gave me a 3-month roadmap, 5 job leads, and told me exactly what was missing. I got hired in 6 weeks.',
    initials: 'RS',
    stars: 5,
  },
  {
    name: 'Aman Kumar',
    role: 'Full-stack Developer',
    company: 'Freelancer → Full-time',
    text: 'The skill gap breakdown was more useful than any bootcamp pitch I have seen. It showed me exactly 3 things to fix and I fixed them.',
    initials: 'AK',
    stars: 5,
  },
  {
    name: 'Priya Mehta',
    role: 'Junior Data Analyst',
    company: 'No degree, hired anyway',
    text: 'I kept getting filtered out for "no degree". Findy showed me the walk-in and freelance paths nobody talks about. Changed everything.',
    initials: 'PM',
    stars: 5,
  },
];

const STATS = [
  { value: '12,000+', label: 'people helped' },
  { value: '98%',     label: 'no-degree paths found' },
  { value: '6 weeks', label: 'avg. time to first job' },
  { value: 'Free',    label: 'no signup needed' },
];

export const LandingPage: React.FC<LandingScreenProps> = ({ onEnterChat, onOpenGov }) => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <div className="min-h-screen w-full bg-[#faf9f7] text-[#1a1a1a]">

      {/* ── Navbar ───────────────────────────────────── */}
      <header className={`fixed top-0 z-50 w-full transition-all duration-300 ${
        scrolled ? 'border-b border-black/[0.06] bg-[#faf9f7]/95 shadow-sm backdrop-blur-xl' : 'bg-transparent'
      }`}>
        <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-4">
          {/* Logo */}
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-[#1a1a1a]">
              <Sparkles size={14} className="text-white" />
            </div>
            <span className="text-[16px] font-bold tracking-tight">Findy</span>
            <span className="rounded-full border border-black/10 bg-black/[0.05] px-2 py-0.5 text-[10px] font-bold text-[#6b6b6b]">AI</span>
          </div>

          {/* Nav links — desktop */}
          <nav className="hidden items-center gap-6 sm:flex">
            {['Features', 'How it works', 'Reviews'].map(l => (
              <a key={l} href={`#${l.toLowerCase().replace(' ', '-')}`}
                className="text-[13px] text-[#6b6b6b] transition hover:text-[#1a1a1a]">{l}</a>
            ))}
          </nav>

          {/* CTA */}
          <button onClick={onEnterChat}
            className="flex items-center gap-2 rounded-xl bg-[#1a1a1a] px-4 py-2.5 text-[13px] font-semibold text-white transition-all hover:bg-black hover:scale-[1.02] active:scale-95">
            Start for free <ChevronRight size={13} />
          </button>
        </div>
      </header>

      {/* ── Hero ─────────────────────────────────────── */}
      <section className="flex min-h-screen flex-col items-center justify-center px-6 pt-20 pb-16 text-center">

        {/* Badge */}
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}
          className="mb-6 inline-flex items-center gap-2 rounded-full border border-black/10 bg-white px-4 py-1.5 shadow-sm">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-[12px] font-medium text-[#6b6b6b]">Free · No signup · AI-powered career intelligence</span>
        </motion.div>

        {/* Headline */}
        <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className="max-w-3xl text-[52px] font-extrabold leading-[1.08] tracking-[-0.04em] text-[#1a1a1a] sm:text-[64px] md:text-[72px]">
          Turn your skills into<br />
          <span className="relative inline-block">
            a real career.
            <motion.div initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ delay: 0.7, duration: 0.5 }}
              className="absolute -bottom-1 left-0 right-0 h-[3px] origin-left rounded-full bg-[#1a1a1a]/20" />
          </span>
        </motion.h1>

        <motion.p initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.18 }}
          className="mt-6 max-w-[480px] text-[16px] leading-7 text-[#6b6b6b]">
          Tell Findy what you know. Get instant job matches, a skill-gap breakdown, and a personal roadmap — no degree required, no cost.
        </motion.p>

        {/* CTA buttons */}
        <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.26 }}
          className="mt-10 flex flex-col items-center gap-3 sm:flex-row">
          <button onClick={onEnterChat}
            className="group flex items-center gap-2.5 rounded-2xl bg-[#1a1a1a] px-8 py-4 text-[15px] font-bold text-white shadow-lg shadow-black/15 transition-all hover:scale-[1.03] hover:shadow-xl active:scale-[0.98]">
            <Sparkles size={16} />
            Start chatting — it's free
            <ArrowRight size={16} className="transition-transform group-hover:translate-x-0.5" />
          </button>
          <button onClick={onOpenGov}
            className="group flex items-center gap-2 rounded-2xl border border-black/10 bg-white px-6 py-4 text-[14px] font-bold text-[#6b6b6b] shadow-sm transition-all hover:border-black/20 hover:text-[#1a1a1a] hover:shadow-md">
            <Globe size={16} /> For Gov / NGO
            <ArrowRight size={14} className="transition-transform group-hover:translate-x-0.5" />
          </button>
        </motion.div>

        {/* Trust row */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.38 }}
          className="mt-8 flex flex-wrap items-center justify-center gap-5 text-[12px] text-[#9a9a9a]">
          {['No account needed', 'Completely free', '12,000+ people helped', '4.9★ rated'].map(t => (
            <span key={t} className="flex items-center gap-1.5">
              <CheckCircle size={12} className="text-emerald-500" /> {t}
            </span>
          ))}
        </motion.div>

        {/* Chat preview card */}
        <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.44, type: 'spring', stiffness: 100 }}
          className="mt-14 w-full max-w-2xl overflow-hidden rounded-3xl border border-black/[0.08] bg-white shadow-2xl shadow-black/10">
          {/* Window chrome */}
          <div className="flex items-center gap-2 border-b border-black/[0.06] bg-[#f5f3f0] px-5 py-3.5">
            <span className="h-3 w-3 rounded-full bg-red-400/80" />
            <span className="h-3 w-3 rounded-full bg-yellow-400/80" />
            <span className="h-3 w-3 rounded-full bg-emerald-400/80" />
            <span className="ml-3 text-[12px] font-medium text-[#9a9a9a]">Findy AI — Career chat</span>
          </div>
          <div className="space-y-4 p-5">
            {/* User message */}
            <div className="flex justify-end">
              <div className="max-w-[75%] rounded-2xl rounded-tr-sm border border-black/[0.07] bg-[#f5f3f0] px-4 py-2.5 text-[13px] leading-6 text-[#1a1a1a]">
                I know HTML, CSS and JavaScript but no degree. What jobs can I actually get?
              </div>
            </div>
            {/* AI response */}
            <div className="flex gap-3">
              <div className="mt-0.5 flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-xl bg-[#1a1a1a]">
                <Sparkles size={12} className="text-white" />
              </div>
              <div className="flex-1 space-y-3">
                <p className="text-[11px] font-semibold text-[#9a9a9a]">Findy AI</p>
                <p className="text-[13px] leading-6 text-[#3a3a3a]">
                  Your skills can get you hired <span className="font-semibold text-[#1a1a1a]">right now</span> — the degree is not the blocker. Here are 3 paths:
                </p>
                <div className="grid gap-2 sm:grid-cols-3">
                  {[
                    { title: 'Junior Frontend Dev', tag: 'Walk-in',  col: 'border-emerald-200 bg-emerald-50 text-emerald-700', pay: '$60k–80k' },
                    { title: 'Freelance Web Dev',    tag: 'Remote',   col: 'border-blue-200 bg-blue-50 text-blue-700',           pay: '$20–35/hr' },
                    { title: 'React Developer',      tag: 'Email HR', col: 'border-violet-200 bg-violet-50 text-violet-700',     pay: '$75k–100k' },
                  ].map(r => (
                    <div key={r.title} className="rounded-xl border border-black/[0.07] bg-[#f8f7f5] p-3">
                      <p className="text-[12px] font-bold text-[#1a1a1a]">{r.title}</p>
                      <p className="mt-0.5 text-[11px] text-[#9a9a9a]">{r.pay}</p>
                      <span className={`mt-1.5 inline-block rounded-md border px-2 py-0.5 text-[10px] font-bold ${r.col}`}>{r.tag}</span>
                    </div>
                  ))}
                </div>
                {/* Progress bar */}
                <div className="rounded-xl border border-black/[0.07] bg-[#f8f7f5] p-3">
                  <div className="mb-1.5 flex justify-between text-[11px]">
                    <span className="font-semibold text-[#1a1a1a]">Job readiness</span>
                    <span className="text-[#6b6b6b]">62% — build 2 projects to reach 85%+</span>
                  </div>
                  <div className="h-1.5 overflow-hidden rounded-full bg-black/[0.06]">
                    <div className="h-full w-[62%] rounded-full bg-[#1a1a1a]" />
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* Input preview */}
          <div className="border-t border-black/[0.06] bg-[#f8f7f5] px-5 py-3.5">
            <div className="flex items-center justify-between rounded-xl border border-black/[0.08] bg-white px-4 py-2.5">
              <span className="text-[13px] text-[#b0b0b0]">Ask about skills, jobs, or your roadmap…</span>
              <button onClick={onEnterChat}
                className="flex items-center gap-2 rounded-lg bg-[#1a1a1a] px-3 py-1.5 text-[12px] font-semibold text-white transition hover:bg-black">
                Try it <ArrowRight size={11} />
              </button>
            </div>
          </div>
        </motion.div>
      </section>

      {/* ── Stats ────────────────────────────────────── */}
      <section className="border-y border-black/[0.06] bg-white py-10">
        <div className="mx-auto grid max-w-4xl grid-cols-2 gap-8 px-6 sm:grid-cols-4">
          {STATS.map(s => (
            <div key={s.label} className="text-center">
              <p className="text-[28px] font-extrabold tracking-tight text-[#1a1a1a]">{s.value}</p>
              <p className="mt-1 text-[13px] text-[#9a9a9a]">{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Features ─────────────────────────────────── */}
      <section id="features" className="py-20">
        <div className="mx-auto max-w-5xl px-6">
          <div className="mb-12 text-center">
            <p className="mb-2 text-[12px] font-bold uppercase tracking-widest text-[#9a9a9a]">Everything in one place</p>
            <h2 className="text-[36px] font-extrabold tracking-[-0.03em] text-[#1a1a1a]">What Findy gives you</h2>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map((f, i) => (
              <motion.div key={f.title}
                initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                className="group rounded-2xl border border-black/[0.07] bg-white p-5 shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md">
                <div className="mb-3 inline-flex h-10 w-10 items-center justify-center rounded-xl bg-[#f0ede8] transition-all group-hover:bg-[#1a1a1a]">
                  <f.icon size={18} className="text-[#6b6b6b] transition-all group-hover:text-white" />
                </div>
                <h3 className="text-[14px] font-bold text-[#1a1a1a]">{f.title}</h3>
                <p className="mt-1.5 text-[13px] leading-5 text-[#6b6b6b]">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── How it works ─────────────────────────────── */}
      <section id="how-it-works" className="border-t border-black/[0.06] bg-white py-20">
        <div className="mx-auto max-w-3xl px-6 text-center">
          <p className="mb-2 text-[12px] font-bold uppercase tracking-widest text-[#9a9a9a]">Simple as messaging a friend</p>
          <h2 className="text-[36px] font-extrabold tracking-[-0.03em] text-[#1a1a1a]">How it works</h2>
          <div className="mt-12 grid gap-6 sm:grid-cols-3">
            {[
              { step: '1', title: 'Describe yourself', desc: 'Tell Findy your skills, background, and what kind of work you are looking for.' },
              { step: '2', title: 'Get your plan',     desc: 'Instantly receive job matches, a skill gap analysis, and a step-by-step roadmap.' },
              { step: '3', title: 'Take action',       desc: 'Walk in, email HR, pitch freelance, or learn the missing skills — with resources included.' },
            ].map(s => (
              <div key={s.step} className="flex flex-col items-center text-center">
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-[#1a1a1a] text-[18px] font-extrabold text-white">
                  {s.step}
                </div>
                <h3 className="text-[14px] font-bold text-[#1a1a1a]">{s.title}</h3>
                <p className="mt-1.5 text-[13px] leading-5 text-[#6b6b6b]">{s.desc}</p>
              </div>
            ))}
          </div>
          <button onClick={onEnterChat}
            className="group mt-12 flex items-center gap-2 mx-auto rounded-2xl bg-[#1a1a1a] px-8 py-4 text-[14px] font-bold text-white shadow-lg transition-all hover:scale-[1.03] active:scale-95">
            <Sparkles size={15} /> Try it now — free <ArrowRight size={14} className="transition-transform group-hover:translate-x-0.5" />
          </button>
        </div>
      </section>

      {/* ── Testimonials ─────────────────────────────── */}
      <section id="reviews" className="py-20">
        <div className="mx-auto max-w-5xl px-6">
          <div className="mb-12 text-center">
            <p className="mb-2 text-[12px] font-bold uppercase tracking-widest text-[#9a9a9a]">Real people, real results</p>
            <h2 className="text-[36px] font-extrabold tracking-[-0.03em] text-[#1a1a1a]">What users say</h2>
            <div className="mt-3 flex items-center justify-center gap-1">
              {[...Array(5)].map((_, i) => <Star key={i} size={16} className="fill-amber-400 text-amber-400" />)}
              <span className="ml-2 text-[13px] text-[#6b6b6b]">4.9 out of 5 · 12,000+ users</span>
            </div>
          </div>
          <div className="grid gap-4 sm:grid-cols-3">
            {TESTIMONIALS.map((t, i) => (
              <motion.div key={t.name}
                initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }} transition={{ delay: i * 0.08 }}
                className="rounded-2xl border border-black/[0.07] bg-white p-5 shadow-sm">
                <div className="mb-4 flex gap-0.5">
                  {[...Array(t.stars)].map((_, j) => <Star key={j} size={13} className="fill-amber-400 text-amber-400" />)}
                </div>
                <p className="text-[13px] leading-6 text-[#3a3a3a]">"{t.text}"</p>
                <div className="mt-4 flex items-center gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-full bg-[#1a1a1a] text-[11px] font-bold text-white">
                    {t.initials}
                  </div>
                  <div>
                    <p className="text-[13px] font-bold text-[#1a1a1a]">{t.name}</p>
                    <p className="text-[11px] text-[#9a9a9a]">{t.role}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Final CTA ────────────────────────────────── */}
      <section className="border-t border-black/[0.06] bg-[#1a1a1a] py-20 text-center text-white">
        <div className="mx-auto max-w-2xl px-6">
          <Sparkles size={32} className="mx-auto mb-5 text-white/40" />
          <h2 className="text-[36px] font-extrabold tracking-[-0.03em]">Ready to get hired?</h2>
          <p className="mt-3 text-[15px] leading-7 text-white/50">
            No account. No credit card. Just describe your skills and Findy does the rest.
          </p>
          <button onClick={onEnterChat}
            className="group mt-8 flex items-center gap-2.5 mx-auto rounded-2xl bg-white px-10 py-4 text-[15px] font-bold text-[#1a1a1a] shadow-xl transition-all hover:scale-[1.03] active:scale-95">
            <Sparkles size={16} className="text-[#1a1a1a]" />
            Start chatting for free
            <ArrowRight size={16} className="transition-transform group-hover:translate-x-0.5" />
          </button>
          <div className="mt-4 flex items-center justify-center gap-5 text-[12px] text-white/30">
            <span>No signup</span><span>·</span><span>Free forever</span><span>·</span><span>12K+ users</span>
          </div>
        </div>
      </section>

      {/* ── Footer ───────────────────────────────────── */}
      <footer className="border-t border-white/10 bg-[#111111] px-6 py-6 text-center text-[12px] text-white/20">
        <div className="flex items-center justify-center gap-2 mb-2">
          <div className="flex h-6 w-6 items-center justify-center rounded-lg bg-white/10">
            <Sparkles size={11} className="text-white/60" />
          </div>
          <span className="font-bold text-white/40">Findy AI</span>
        </div>
        Findy AI may make mistakes. Always verify important career information independently.
      </footer>
    </div>
  );
};
