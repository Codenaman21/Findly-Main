import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowUp, Mic, Briefcase, MapPin, BookOpen, TrendingUp, Sparkles, Lightbulb } from 'lucide-react';

interface ChatStartScreenProps {
  onSend: (text: string) => void;
}

const SUGGESTIONS = [
  { icon: Briefcase, text: 'I know HTML, CSS and JS. What jobs can I get without a degree?',      color: 'text-[#f5c842]', bg: 'bg-[#f5c842]/[0.05] border-[#f5c842]/20 hover:border-[#f5c842]/40 hover:bg-[#f5c842]/[0.08]' },
  { icon: MapPin,     text: 'Show me entry-level tech jobs near me I can apply to now',            color: 'text-zinc-300',   bg: 'bg-white/[0.02] border-white/[0.07] hover:border-white/[0.14] hover:bg-white/[0.04]' },
  { icon: BookOpen,   text: 'Build me a 3-month roadmap to become a frontend developer',           color: 'text-zinc-300',   bg: 'bg-white/[0.02] border-white/[0.07] hover:border-white/[0.14] hover:bg-white/[0.04]' },
  { icon: TrendingUp, text: 'Analyse my skills and tell me what I am missing to get hired',        color: 'text-[#f5c842]', bg: 'bg-[#f5c842]/[0.05] border-[#f5c842]/20 hover:border-[#f5c842]/40 hover:bg-[#f5c842]/[0.08]' },
];

export const ChatStartScreen: React.FC<ChatStartScreenProps> = ({ onSend }) => {
  const [prompt, setPrompt] = useState('');
  const [isRecording, setIsRecording] = useState(false);

  const submitPrompt = (text: string) => {
    const trimmed = text.trim();
    if (!trimmed) return;
    onSend(trimmed);
    setPrompt('');
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitPrompt(prompt);
  };

  return (
    <div className="flex min-h-full w-full flex-col items-center justify-center px-4 py-12 sm:px-6">
      <div className="w-full max-w-2xl">
        {/* Greeting */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-10 text-center"
        >
          <div className="mb-4 inline-flex h-14 w-14 items-center justify-center rounded-2xl border border-[#f5c842]/30 bg-[#f5c842]/10">
            <Sparkles size={26} className="text-[#f5c842]" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
            What can I help you find?
          </h1>
          <p className="mt-3 text-[15px] leading-7 text-zinc-600">
            Tell me your skills, situation, or goals — I'll map your path.
          </p>
        </motion.div>

        {/* Input Box */}
        <motion.form
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15, duration: 0.5 }}
          onSubmit={handleFormSubmit}
        >
          <div className="relative flex flex-col rounded-2xl border border-white/[0.08] bg-[#0d0d0d] shadow-2xl shadow-black/80 transition-all focus-within:border-[#f5c842]/30">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  submitPrompt(prompt);
                }
              }}
              rows={3}
              placeholder="Example: I know Python and data analysis but no degree. I want to earn ₹60k/month in 3 months."
              className="max-h-40 w-full resize-none bg-transparent px-5 pt-4 pb-2 text-[15px] leading-7 text-white placeholder-zinc-600 focus:outline-none"
            />
            <div className="flex items-center justify-between px-4 pb-3 pt-1">
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setIsRecording(!isRecording)}
                  className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium transition-all ${isRecording ? 'bg-red-500/20 text-red-300 border border-red-500/30 animate-pulse' : 'text-zinc-600 hover:text-white hover:bg-white/[0.04]'}`}
                >
                  <Mic size={13} />
                  {isRecording ? 'Recording…' : 'Voice'}
                </button>
                <span className="text-xs text-zinc-700">Shift+Enter for new line</span>
              </div>
              <button
                type="submit"
                disabled={!prompt.trim()}
                className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#f5c842] text-black shadow-md shadow-[#f5c842]/20 transition-all hover:scale-105 hover:bg-[#f7d05e] disabled:bg-white/5 disabled:text-zinc-700 disabled:shadow-none disabled:scale-100"
              >
                <ArrowUp size={16} className="text-white" strokeWidth={2.5} />
              </button>
            </div>
          </div>
        </motion.form>

        {/* Tip */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.25 }}
          className="mt-3 flex items-center justify-center gap-1.5 text-xs text-zinc-600"
        >
          <Lightbulb size={11} className="text-amber-500" />
          Tip: the more detail you give, the better your roadmap
        </motion.div>

        {/* Suggestion pills */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.5 }}
          className="mt-6 grid gap-2 sm:grid-cols-2"
        >
          {SUGGESTIONS.map((s) => (
            <button
              key={s.text}
              onClick={() => submitPrompt(s.text)}
              className={`group flex items-start gap-3 rounded-xl border p-3.5 text-left transition-all duration-200 ${s.bg}`}
            >
              <s.icon size={15} className={`mt-0.5 shrink-0 ${s.color}`} />
              <span className="text-[13px] leading-5 text-zinc-300 group-hover:text-white transition-colors">
                {s.text}
              </span>
            </button>
          ))}
        </motion.div>
      </div>
    </div>
  );
};
