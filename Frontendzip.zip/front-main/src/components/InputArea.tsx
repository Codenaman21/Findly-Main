import React, { useState, useRef, useEffect } from 'react';
import { ArrowUp, Mic, Square, Sparkles } from 'lucide-react';

interface InputAreaProps {
  onSend: (text: string) => void;
  isTyping: boolean;
}

export const InputArea: React.FC<InputAreaProps> = ({ onSend, isTyping }) => {
  const [input, setInput] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [focused, setFocused] = useState(false);
  
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 140)}px`;
    }
  }, [input]);

  // ── Voice Recognition Logic ──────────────────────────────
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onresult = (event: any) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          transcript += event.results[i][0].transcript;
        }
        setInput(prev => prev + (prev.endsWith(' ') || prev === '' ? '' : ' ') + transcript);
      };

      recognition.onend = () => setIsRecording(false);
      recognition.onerror = () => setIsRecording(false);
      recognitionRef.current = recognition;
    }
  }, []);

  const toggleVoice = () => {
    if (!recognitionRef.current) {
      alert("Speech recognition is not supported in this browser.");
      return;
    }

    if (isRecording) {
      recognitionRef.current.stop();
      setIsRecording(false);
    } else {
      recognitionRef.current.start();
      setIsRecording(true);
    }
  };

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (input.trim() && !isTyping) {
      onSend(input.trim());
      setInput('');
      if (textareaRef.current) textareaRef.current.style.height = 'auto';
    }
  };

  const canSend = !!input.trim() && !isTyping;

  return (
    <div className="flex-shrink-0 px-6 pb-6 pt-2">
      <form onSubmit={handleSubmit} className="mx-auto max-w-3xl">
        <div className={`group relative flex flex-col rounded-[28px] border bg-white/80 backdrop-blur-xl transition-all duration-500 ${
          focused ? 'border-black/20 shadow-[0_20px_50px_rgba(0,0,0,0.1)] ring-8 ring-black/[0.02]' : 'border-black/[0.06] shadow-sm'
        }`}>
          
          <textarea
            ref={textareaRef}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSubmit(); } }}
            onFocus={() => setFocused(true)}
            onBlur={() => setFocused(false)}
            placeholder="Talk to Findy — your career mentor"
            rows={1}
            className="scrollbar-hide max-h-[160px] w-full resize-none bg-transparent px-6 pt-5 pb-3 text-[16px] leading-relaxed text-[#1a1a1a] placeholder-[#b0b0b0] outline-none"
          />
          
          <div className="flex items-center justify-between px-4 pb-4 pt-1">
            <div className="flex items-center gap-2">
              <button type="button" onClick={toggleVoice}
                className={`flex items-center gap-2.5 rounded-2xl px-4 py-2.5 text-[13px] font-bold transition-all active:scale-95 ${
                  isRecording 
                    ? 'animate-pulse bg-red-500 text-white shadow-lg shadow-red-200' 
                    : 'bg-[#f5f3f0] text-[#6b6b6b] hover:bg-[#eceae6] hover:text-[#1a1a1a]'
                }`}>
                {isRecording ? <Square size={14} fill="currentColor" /> : <Mic size={15} />}
                {isRecording ? 'Listening…' : 'Voice Assistant'}
              </button>
            </div>

            <div className="flex items-center gap-3">
              {isTyping && (
                <div className="flex items-center gap-2 px-3">
                  <Sparkles size={14} className="animate-pulse text-amber-500" />
                  <span className="text-[12px] font-bold text-[#9a9a9a]">Findy is thinking</span>
                </div>
              )}
              <button type="submit" disabled={!canSend}
                className={`flex h-11 w-11 items-center justify-center rounded-2xl shadow-xl transition-all duration-300 ${
                  canSend 
                    ? 'bg-[#1a1a1a] text-white hover:scale-105 hover:shadow-black/20 active:scale-95' 
                    : 'cursor-not-allowed bg-[#e0ddd8] text-[#b0b0b0] shadow-none'
                }`}>
                <ArrowUp size={20} strokeWidth={3} />
              </button>
            </div>
          </div>
        </div>
        <p className="mt-3 text-center text-[11px] font-medium tracking-tight text-[#b0b0b0]">
          Voice analysis active · Type or speak to get your roadmap
        </p>
      </form>
    </div>
  );
};
