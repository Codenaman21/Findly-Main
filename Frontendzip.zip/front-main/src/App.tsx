import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChatMessage } from './components/ChatMessage';
import { InputArea } from './components/InputArea';
import { LandingPage } from './components/LandingPage';
import { GovDashboard } from './components/GovDashboard';
import type { Message, AIResponseData } from './types';
import {
  Home, BookOpen, Settings, Sparkles, Plus,
  TrendingUp, X, User, Star, Mail, Calendar, 
  ArrowRight, CheckCircle2, Lock, Globe, Palette
} from 'lucide-react';

/* ── Dummy AI Response Generator ────────────────────────── */
const generateAIResponse = (): AIResponseData => ({
  textResponse: "Your background is a strength, not a weakness. Here is how you can pivot successfully.",
  role: "Lead Interface Designer",
  opportunities: [
    { id: '1', role: 'UI Engineer',   location: 'Remote', salary: '$85k–$115k' },
    { id: '2', role: 'Product Designer', location: 'London/Hybrid', salary: '$70k–$95k' },
    { id: '3', role: 'Frontend Architect', location: 'Contract', salary: '$90/hr' },
  ],
  skills: { present: ['Visual Design', 'Figma', 'React Basics'], missing: ['Advanced Prototype', 'System Design'] },
  mapPoints: [
    { id: 'm1', lat: 38, lng: 42, role: 'Designer @ CreativeCo' },
    { id: 'm2', lat: 60, lng: 50, role: 'UI Lead @ FutureInc' },
  ],
  risk: { level: 'Low', explanation: 'Design roles are high in demand for skill-first applicants.' },
  roadmap: [
    { month: 1, title: 'Case Study Prep', description: 'Document your process for 2 key projects.' },
    { month: 2, title: 'System Mastery', description: 'Build a full design system in Figma and React.' },
    { month: 3, title: 'Direct Outreach', description: 'Pitch to 5 startup founders directly on LinkedIn.' },
  ],
  resources: [
    { id: 'r1', title: 'Design Systems 101', type: 'Course', url: 'https://example.com' },
    { id: 'r2', title: 'Figma Mastery', type: 'Tool', url: 'https://example.com' },
  ],
});

/* ── UI Components ──────────────────────────────────────── */

const StarIcon = () => (
  <svg width="64" height="64" viewBox="0 0 72 72" fill="none">
    <path d="M36 4 L40 32 L68 36 L40 40 L36 68 L32 40 L4 36 L32 32 Z" fill="url(#sg)" opacity="0.9" />
    <defs>
      <linearGradient id="sg" x1="4" y1="4" x2="68" y2="68" gradientUnits="userSpaceOnUse">
        <stop stopColor="#c084fc" /><stop offset="0.5" stopColor="#f472b6" /><stop offset="1" stopColor="#818cf8" />
      </linearGradient>
    </defs>
  </svg>
);

const AccountPanel: React.FC<{ onClose: () => void }> = ({ onClose }) => (
  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[100] flex" onClick={onClose}>
    <div className="absolute inset-0 bg-black/40 backdrop-blur-md" />
    <motion.div initial={{ x: -360 }} animate={{ x: 0 }} exit={{ x: -360 }} transition={{ type: 'spring', damping: 28, stiffness: 220 }}
      onClick={e => e.stopPropagation()} className="relative z-10 flex h-full w-[360px] flex-col bg-white shadow-2xl">
      <div className="flex items-center justify-between border-b border-black/[0.05] px-8 py-6">
        <h2 className="text-[20px] font-black">Profile</h2>
        <button onClick={onClose} className="p-2.5 rounded-2xl bg-[#f5f3f0] text-[#6b6b6b] hover:bg-[#eceae6] transition"><X size={18} /></button>
      </div>
      <div className="flex flex-col items-center py-10 border-b border-black/[0.05]">
        <div className="relative">
          <div className="flex h-24 w-24 items-center justify-center rounded-[32px] bg-[#1a1a1a] text-[28px] font-black text-white shadow-2xl">KG</div>
          <div className="absolute -bottom-1 -right-1 h-7 w-7 rounded-full border-4 border-white bg-emerald-500 shadow-lg" />
        </div>
        <h3 className="mt-5 text-[22px] font-black">Kartik Guleria</h3>
        <p className="text-[14px] font-medium text-[#9a9a9a]">@kartik_g · Premium AI Member</p>
      </div>
      <div className="p-8 space-y-6 flex-1 overflow-y-auto scrollbar-hide">
        {[
          { icon: Mail, label: 'Email Address', val: 'kartik@example.com' },
          { icon: Calendar, label: 'Member Since', val: 'April 2026' }
        ].map(i => (
          <div key={i.label} className="flex items-center gap-5">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#f5f3f0]"><i.icon size={18} className="text-[#6b6b6b]" /></div>
            <div><p className="text-[11px] font-bold uppercase tracking-widest text-[#9a9a9a] mb-0.5">{i.label}</p><p className="text-[15px] font-bold text-[#1a1a1a]">{i.val}</p></div>
          </div>
        ))}
        <div className="pt-4 grid grid-cols-2 gap-4">
          <div className="p-5 rounded-[24px] bg-[#f8f7f5] border border-black/[0.04] text-center shadow-sm">
            <TrendingUp size={20} className="mx-auto mb-2 text-emerald-500" /><p className="text-[24px] font-black">12</p><p className="text-[11px] font-bold text-[#9a9a9a] uppercase tracking-wider">Sessions</p>
          </div>
          <div className="p-5 rounded-[24px] bg-[#f8f7f5] border border-black/[0.04] text-center shadow-sm">
            <Star size={20} className="mx-auto mb-2 text-amber-500" /><p className="text-[24px] font-black">8</p><p className="text-[11px] font-bold text-[#9a9a9a] uppercase tracking-wider">Awards</p>
          </div>
        </div>
      </div>
      <div className="p-8 border-t border-black/[0.05]">
        <button className="w-full py-4 rounded-2xl bg-red-50 text-red-500 font-black text-[14px] hover:bg-red-100 transition flex items-center justify-center gap-2">Sign Out Account <ArrowRight size={16} /></button>
      </div>
    </motion.div>
  </motion.div>
);

/* ── Main App ───────────────────────────────────────────── */

export default function App() {
  const [showLanding, setShowLanding] = useState(true);
  const [showGov, setShowGov] = useState(false);
  const [activeNav, setActiveNav] = useState('Home');
  const [inChat, setInChat] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [loadingText, setLoadingText] = useState('');
  const [showAccount, setShowAccount] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => { 
    if (messagesEndRef.current) {
      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    }
  }, [messages, isTyping]);

  const handleSend = (text: string) => {
    const trimmed = text.trim();
    if (!trimmed) return;
    setActiveNav('Home');
    setInChat(true);
    const userMsg = { id: Math.random().toString(), role: 'user' as const, content: trimmed };
    setMessages(prev => [...prev, userMsg]);
    setIsTyping(true);
    setLoadingText('Analysing your request...');
    const apiUrl = import.meta.env.VITE_API_URL;
    
    if (apiUrl) {
      // Send to friend's backend if the URL is configured in .env
      fetch(`${apiUrl}/api/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: trimmed })
      })
      .then(res => res.json())
      .then(data => {
        const aiMsg = { id: Math.random().toString(), role: 'ai' as const, content: data };
        setMessages(prev => [...prev, aiMsg]);
      })
      .catch(err => {
        console.error('Failed to reach backend, falling back to mock:', err);
        const aiMsg = { id: Math.random().toString(), role: 'ai' as const, content: generateAIResponse() };
        setMessages(prev => [...prev, aiMsg]);
      })
      .finally(() => setIsTyping(false));
    } else {
      // Fallback to local mock simulation
      setTimeout(() => {
        const aiMsg = { id: Math.random().toString(), role: 'ai' as const, content: generateAIResponse() };
        setMessages(prev => [...prev, aiMsg]);
        setIsTyping(false);
      }, 2000);
    }
  };

  const newChat = () => {
    setMessages([]);
    setInChat(false);
    setActiveNav('Home');
  };

  if (showLanding) {
    return <LandingPage onEnterChat={() => setShowLanding(false)} onOpenGov={() => { setShowLanding(false); setShowGov(true); }} />;
  }

  if (showGov) {
    return <GovDashboard onBack={() => { setShowGov(false); setShowLanding(true); }} />;
  }

  return (
    <div className="flex h-screen w-full overflow-hidden bg-[#f0ede8] font-sans text-[#1a1a1a]">
      <AnimatePresence>
        {showAccount && <AccountPanel onClose={() => setShowAccount(false)} />}
      </AnimatePresence>

      {/* SIDEBAR */}
      <aside className="w-[240px] flex-shrink-0 bg-[#ebe8e3] border-r border-black/[0.06] flex flex-col py-8">
        <button onClick={() => setShowLanding(true)} className="flex items-center gap-3 px-8 mb-12 cursor-pointer hover:opacity-80 transition-opacity text-left">
          <div className="w-10 h-10 rounded-2xl bg-black flex items-center justify-center shadow-2xl shadow-black/20"><Sparkles size={18} className="text-white" /></div>
          <span className="font-black text-[20px] tracking-tighter">FINDY</span>
        </button>
        
        <nav className="px-4 space-y-2">
          {[
            { l: 'Home', i: Home },
            { l: 'Resources', i: BookOpen },
            { l: 'Settings', i: Settings }
          ].map(n => (
            <button key={n.l} onClick={() => setActiveNav(n.l)}
              className={`w-full flex items-center gap-3.5 px-5 py-4 rounded-2xl font-black text-[15px] transition-all duration-300 ${
                activeNav === n.l 
                  ? 'bg-white text-black shadow-xl shadow-black/[0.03] scale-[1.02]' 
                  : 'text-[#6b6b6b] hover:bg-black/[0.04] hover:text-[#1a1a1a]'
              }`}>
              <n.i size={20} strokeWidth={activeNav === n.l ? 3 : 2} /> {n.l}
            </button>
          ))}
        </nav>

        <div className="mt-auto px-4">
          <button onClick={newChat} 
            className="w-full flex items-center justify-center gap-2.5 py-4 bg-white border border-black/[0.08] rounded-2xl font-black text-[14px] shadow-sm hover:shadow-xl hover:-translate-y-0.5 transition-all active:scale-95 mb-6">
            <Plus size={18} strokeWidth={3} /> New session
          </button>
          
          <div className="p-5 rounded-[28px] bg-[#1a1a1a] text-white shadow-2xl shadow-black/20 group cursor-pointer overflow-hidden relative" onClick={() => setShowAccount(true)}>
            <div className="absolute inset-0 bg-gradient-to-br from-white/[0.05] to-transparent pointer-events-none" />
            <div className="flex items-center gap-4 mb-4">
              <div className="w-11 h-11 rounded-2xl bg-white/10 flex items-center justify-center font-black text-[14px] group-hover:bg-white/20 transition-colors">KG</div>
              <div className="min-w-0"><p className="font-black text-[14px] truncate">Kartik G.</p><p className="text-[11px] text-white/40 font-bold uppercase tracking-wider">Premium Plan</p></div>
            </div>
            <div className="w-full py-2.5 bg-white/5 rounded-xl text-[12px] font-black flex items-center justify-center gap-2 group-hover:bg-white/15 transition-all">
              <User size={13} /> View profile
            </div>
          </div>
        </div>
      </aside>

      {/* MAIN */}
      <main className="flex-1 flex flex-col overflow-hidden bg-white/40 backdrop-blur-3xl">
        <header className="flex items-center justify-between px-10 py-6 border-b border-black/[0.04] bg-white/20">
          <div className="flex items-center gap-3.5">
            <div className={`w-3 h-3 rounded-full shadow-lg ${isTyping ? 'bg-amber-400 animate-pulse shadow-amber-200' : 'bg-emerald-500 shadow-emerald-200'}`} />
            <span className="font-black text-[15px] tracking-tight">{isTyping ? 'Assistant is thinking…' : 'Assistant is online'}</span>
          </div>
          {inChat && (
            <button onClick={newChat} className="text-[13px] font-black text-[#6b6b6b] hover:text-red-500 transition-colors flex items-center gap-2 px-4 py-2 rounded-xl hover:bg-red-50">
              <Plus size={16} strokeWidth={3} /> Clear session
            </button>
          )}
        </header>

        <div className="flex-1 overflow-y-auto scrollbar-hide">
          <AnimatePresence mode="wait">
            {activeNav === 'Home' && !inChat && (
              <motion.div key="home" initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.98 }} 
                className="flex h-full flex-col items-center justify-center p-12 text-center">
                <motion.div initial={{ rotate: -10, scale: 0.8 }} animate={{ rotate: 0, scale: 1 }} transition={{ type: 'spring', damping: 15 }}>
                  <StarIcon />
                </motion.div>
                <h1 className="mt-8 text-[44px] font-black tracking-tight text-[#1a1a1a] leading-tight">Find your path,<br />the skill-first way.</h1>
                <p className="mt-4 text-[18px] font-medium text-[#9a9a9a] max-w-md">Let AI build your roadmap. No degree filters, no gatekeepers. Just proof of work.</p>
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="mt-12">
                   <div className="p-1 rounded-full bg-black/5 flex items-center gap-2">
                     <div className="h-2 w-2 rounded-full bg-emerald-500 ml-4 animate-pulse" />
                     <span className="text-[13px] font-bold text-[#6b6b6b] pr-4 py-2">AI is ready for your query</span>
                   </div>
                </motion.div>
              </motion.div>
            )}

            {activeNav === 'Home' && inChat && (
              <motion.div key="chat" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mx-auto w-full max-w-3xl px-6 py-10">
                {messages.map(msg => <ChatMessage key={msg.id} message={msg} />)}
                {isTyping && (
                  <div className="mt-6 flex items-start gap-4 px-2">
                    <div className="w-8 h-8 rounded-2xl bg-black flex items-center justify-center text-white shadow-lg"><Sparkles size={14} /></div>
                    <div className="p-5 bg-white border border-black/[0.05] rounded-3xl shadow-xl flex items-center gap-3">
                      <div className="flex gap-1.5">
                        {[0, 0.2, 0.4].map(d => <motion.div key={d} animate={{ opacity: [0.3, 1, 0.3], scale: [1, 1.2, 1] }} transition={{ repeat: Infinity, duration: 1, delay: d }} className="w-2.5 h-2.5 rounded-full bg-black" />)}
                      </div>
                      <span className="text-[13px] font-bold text-[#9a9a9a] tracking-tight">{loadingText}</span>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} className="h-16" />
              </motion.div>
            )}

            {activeNav === 'Resources' && (
              <motion.div key="res" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="p-12 max-w-5xl mx-auto">
                <h2 className="text-[36px] font-black mb-10 tracking-tight">Career Resources</h2>
                <div className="grid grid-cols-2 gap-6">
                  {[
                    { t: 'Learning Path', d: 'Curated materials for frontend & design.', c: 'bg-blue-50 text-blue-600', i: BookOpen },
                    { t: 'Resource Kit', d: 'Templates, tools and email scripts.', c: 'bg-emerald-50 text-emerald-600', i: Sparkles },
                    { t: 'Portfolio Mastery', d: 'How to build proof that gets hired.', c: 'bg-purple-50 text-purple-600', i: Star },
                    { t: 'Interview Prep', d: 'Mock questions and strategy guide.', c: 'bg-amber-50 text-amber-600', i: CheckCircle2 }
                  ].map(r => (
                    <div key={r.t} className="p-8 rounded-[32px] bg-white border border-black/[0.05] shadow-sm hover:shadow-2xl hover:-translate-y-1 transition-all cursor-pointer group">
                      <div className={`w-14 h-14 rounded-2xl ${r.c} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}><r.i size={28} /></div>
                      <h3 className="font-black text-[20px] mb-2">{r.t}</h3>
                      <p className="text-[15px] font-medium text-[#9a9a9a] leading-relaxed">{r.d}</p>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {activeNav === 'Settings' && (
              <motion.div key="sett" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="p-12 max-w-3xl mx-auto">
                <h2 className="text-[36px] font-black mb-10 tracking-tight">App Settings</h2>
                <div className="bg-white rounded-[32px] border border-black/[0.05] shadow-xl overflow-hidden p-4">
                  {[
                    { l: 'Push Notifications', d: 'Real-time job match alerts', i: Sparkles },
                    { l: 'Private Profile Mode', d: 'Hide account from searches', i: Lock },
                    { l: 'Visual Theme', d: 'Switch to warm light mode', i: Palette }
                  ].map((s, idx) => (
                    <div key={s.l} className={`p-6 flex items-center justify-between transition-colors hover:bg-black/[0.02] cursor-pointer ${idx !== 2 ? 'border-b border-black/[0.03]' : ''}`}>
                      <div className="flex items-center gap-5">
                        <div className="w-12 h-12 rounded-2xl bg-[#f5f3f0] flex items-center justify-center text-[#1a1a1a]"><s.i size={20} /></div>
                        <div><p className="font-black text-[16px]">{s.l}</p><p className="text-[13px] font-medium text-[#9a9a9a]">{s.d}</p></div>
                      </div>
                      <div className="w-12 h-6 bg-black rounded-full relative p-1 transition-all">
                        <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full shadow-lg" />
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <InputArea onSend={handleSend} isTyping={isTyping} />
      </main>
    </div>
  );
}
