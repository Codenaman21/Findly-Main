export type RoleType = string;

export interface Opportunity {
  id: string;
  role: string;
  location: string;
  salary: string;
}

export interface SkillSet {
  present: string[];
  missing: string[];
}

export interface RiskAnalysis {
  level: 'Low' | 'Medium' | 'High';
  explanation: string;
}

export interface RoadmapStep {
  month: number;
  title: string;
  description: string;
}

export interface Resource {
  id: string;
  title: string;
  type: 'Course' | 'Tool' | 'Platform';
  url: string;
}

export interface MapPoint {
  id: string;
  lat: number;
  lng: number;
  role: string;
}

export interface AIResponseData {
  role?: RoleType;
  opportunities?: Opportunity[];
  skills?: SkillSet;
  risk?: RiskAnalysis;
  roadmap?: RoadmapStep[];
  resources?: Resource[];
  mapPoints?: MapPoint[];
  textResponse?: string; // Optional text accompanying the cards
}

export interface Message {
  id: string;
  role: 'user' | 'ai';
  content: string | AIResponseData | any; // allow new backend format
}

// --- New Backend Types ---

export interface BackendIntent {
  intent: 'opportunity' | 'learning' | string;
  confidence: number;
  source: string;
}

export interface BackendISCO {
  isco_code: string;
  title: string;
  skill: string;
  mapped: boolean;
  explanation: string;
  confidence: string;
}

export interface BackendJob {
  title: string;
  company: string;
  location: string;
  link: string;
  source: string;
}

export interface BackendOpportunities {
  primary_tier?: string;
  summary?: string;
  jobs?: {
    count: number;
    jobs: BackendJob[];
  };
  freelance?: {
    count: number;
    opportunities: any[];
  };
  walkin?: {
    count: number;
    places: any[];
  };
}

export interface BackendLearningPlan {
  role: string;
  stage: string;
  progress: {
    percent_complete: number;
    total_required: number;
    user_has: number;
  };
  focus_skills: string[];
  resources: Record<string, Record<string, string>>;
}

export interface BackendResponse {
  success: boolean;
  response: string;
  data: {
    intent?: BackendIntent;
    isco_mapping?: BackendISCO[];
    opportunities?: BackendOpportunities;
    learning_plan?: BackendLearningPlan;
    skills?: any;
  };
}
